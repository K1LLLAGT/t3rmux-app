/*
 * libwebsockets - small server side websockets and web server implementation
 *
 * Copyright (C) 2010 - 2020 Andy Green <andy@warmcat.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

/* minimal space for typical headers and CSP stuff */

#define LWS_RECOMMENDED_MIN_HEADER_SPACE 2048

/*! \defgroup http HTTP

    Modules related to handling HTTP
*/
//@{

/*! \defgroup httpft HTTP File transfer
 * \ingroup http

    APIs for sending local files in response to HTTP requests
*/
//@{

/**
 * lws_get_mimetype() - Determine mimetype to use from filename
 *
 * \param file:		filename
 * \param m:		NULL, or mount context
 *
 * This uses a canned list of known filetypes first, if no match and m is
 * non-NULL, then tries a list of per-mount file suffix to mimtype mappings.
 *
 * Returns either NULL or a pointer to the mimetype matching the file.
 */
LWS_VISIBLE LWS_EXTERN const char *
lws_get_mimetype(const char *file, const struct lws_http_mount *m);

/**
 * lws_find_mount() - Find the mount context for a URI
 *
 * \param wsi:		wsi context
 * \param uri_ptr:	pointer to the URI
 * \param uri_len:	length of the URI
 *
 * Returns NULL or a pointer to the matching mount.
 */
#if defined(LWS_ROLE_H1) || defined(LWS_ROLE_H2) || defined(LWS_ROLE_H3)
LWS_VISIBLE LWS_EXTERN const struct lws_http_mount *
lws_find_mount(struct lws *wsi, const char *uri_ptr, int uri_len);
#endif

/**
 * lws_serve_http_file() - Send a file back to the client using http
 * \param wsi:		Websocket instance (available from user callback)
 * \param file:		The file to issue over http
 * \param content_type:	The http content type, eg, text/html
 * \param other_headers:	NULL or pointer to header string
 * \param other_headers_len:	length of the other headers if non-NULL
 *
 *	This function is intended to be called from the callback in response
 *	to http requests from the client.  It allows the callback to issue
 *	local files down the http link in a single step.
 *
 *	Returning <0 indicates error and the wsi should be closed.  Returning
 *	>0 indicates the file was completely sent and
 *	lws_http_transaction_completed() called on the wsi (and close if != 0)
 *	==0 indicates the file transfer is started and needs more service later,
 *	the wsi should be left alone.
 */
LWS_VISIBLE LWS_EXTERN int
lws_serve_http_file(struct lws *wsi, const char *file, const char *content_type,
		    const char *other_headers, int other_headers_len);

LWS_VISIBLE LWS_EXTERN int
lws_serve_http_file_fragment(struct lws *wsi);
//@}


enum http_status {
	HTTP_STATUS_CONTINUE					= 100,

	HTTP_STATUS_OK						= 200,
	HTTP_STATUS_NO_CONTENT					= 204,
	HTTP_STATUS_PARTIAL_CONTENT				= 206,

	HTTP_STATUS_MOVED_PERMANENTLY				= 301,
	HTTP_STATUS_FOUND					= 302,
	HTTP_STATUS_SEE_OTHER					= 303,
	HTTP_STATUS_NOT_MODIFIED				= 304,

	HTTP_STATUS_BAD_REQUEST					= 400,
	HTTP_STATUS_UNAUTHORIZED,
	HTTP_STATUS_PAYMENT_REQUIRED,
	HTTP_STATUS_FORBIDDEN,
	HTTP_STATUS_NOT_FOUND,
	HTTP_STATUS_METHOD_NOT_ALLOWED,
	HTTP_STATUS_NOT_ACCEPTABLE,
	HTTP_STATUS_PROXY_AUTH_REQUIRED,
	HTTP_STATUS_REQUEST_TIMEOUT,
	HTTP_STATUS_CONFLICT,
	HTTP_STATUS_GONE,
	HTTP_STATUS_LENGTH_REQUIRED,
	HTTP_STATUS_PRECONDITION_FAILED,
	HTTP_STATUS_REQ_ENTITY_TOO_LARGE,
	HTTP_STATUS_REQ_URI_TOO_LONG,
	HTTP_STATUS_UNSUPPORTED_MEDIA_TYPE,
	HTTP_STATUS_REQ_RANGE_NOT_SATISFIABLE,
	HTTP_STATUS_EXPECTATION_FAILED,

	HTTP_STATUS_UPGRADE_REQUIRED				= 426,
	HTTP_STATUS_REQ_HEADER_FIELDS_TOO_LARGE			= 431,

	HTTP_STATUS_INTERNAL_SERVER_ERROR			= 500,
	HTTP_STATUS_NOT_IMPLEMENTED,
	HTTP_STATUS_BAD_GATEWAY,
	HTTP_STATUS_SERVICE_UNAVAILABLE,
	HTTP_STATUS_GATEWAY_TIMEOUT,
	HTTP_STATUS_HTTP_VERSION_NOT_SUPPORTED,
};
/*! \defgroup html-chunked-substitution HTML Chunked Substitution
 * \ingroup http
 *
 * ##HTML chunked Substitution
 *
 * APIs for receiving chunks of text, replacing a set of variable names via
 * a callback, and then prepending and appending HTML chunked encoding
 * headers.
 */
//@{

struct lws_process_html_args {
	char *p; /**< pointer to the buffer containing the data */
	int len; /**< length of the original data at p */
	int max_len; /**< maximum length we can grow the data to */
	int final; /**< set if this is the last chunk of the file */
	int chunked; /**< 0 == unchunked, 1 == produce chunk headers
			(incompatible with HTTP/2) */
};

typedef const char *(*lws_process_html_state_cb)(void *data, int index);

struct lws_process_html_state {
	char *start; /**< unused */
	char swallow[16]; /**< the start of a variable the last lump ended
			   * with, held back for the next */
	int pos; /**< how much is held back in swallow; start at 0 */
	void *data; /**< opaque pointer */
	const char * const *vars; /**< list of variable names */
	int count_vars; /**< count of variable names */

	lws_process_html_state_cb replace;
		/**< called on match to perform substitution */
};

/*! lws_chunked_html_process() - generic chunked substitution
 * \param args: buffer to process using chunked encoding
 * \param s: current processing state
 *
 * Replaces the variables named in \p s in one lump of the file, in place,
 * and adds the chunk framing when \p args->chunked.  Variables can be up to
 * 14 characters, and one may be split across two lumps: the part at the end
 * of a lump is held back in \p s and processed with the next one, so
 * \p args->len can come back 0 for a lump that is not the last.  Returns 0,
 * or -1 if the content would outgrow \p args->max_len.
 */
LWS_VISIBLE LWS_EXTERN int
lws_chunked_html_process(struct lws_process_html_args *args,
			 struct lws_process_html_state *s);
//@}

/** \defgroup HTTP-headers-read HTTP headers: read
 * \ingroup http
 *
 * ##HTTP header releated functions
 *
 *  In lws the client http headers are temporarily stored in a pool, only for the
 *  duration of the http part of the handshake.  It's because in most cases,
 *  the header content is ignored for the whole rest of the connection lifetime
 *  and would then just be taking up space needlessly.
 *
 *  During LWS_CALLBACK_HTTP when the URI path is delivered is the last time
 *  the http headers are still allocated, you can use these apis then to
 *  look at and copy out interesting header content (cookies, etc)
 *
 *  Notice that the header total length reported does not include a terminating
 *  '\0', however you must allocate for it when using the _copy apis.  So the
 *  length reported for a header containing "123" is 3, but you must provide
 *  a buffer of length 4 so that "123\0" may be copied into it, or the copy
 *  will fail with a nonzero return code.
 *
 *  In the special case of URL arguments, like ?x=1&y=2, the arguments are
 *  stored in a token named for the method, eg,  WSI_TOKEN_GET_URI if it
 *  was a GET or WSI_TOKEN_POST_URI if POST.  You can check the total
 *  length to confirm the method.
 *
 *  For URL arguments, each argument is stored urldecoded in a "fragment", so
 *  you can use the fragment-aware api lws_hdr_copy_fragment() to access each
 *  argument in turn: the fragments contain urldecoded strings like x=1 or y=2.
 *
 *  The parser refuses (403 on h1) any request whose URI contains a C0
 *  control byte or DEL, raw or percent-encoded, so urlarg values only ever
 *  contain printable and high (>= 0x80, eg UTF-8) bytes.
 *
 *  As a convenience, lws has an api that will find the fragment with a
 *  given name= part, lws_get_urlarg_by_name_safe().
 */
///@{

/** struct lws_tokens
 * you need these to look at headers that have been parsed if using the
 * LWS_CALLBACK_FILTER_CONNECTION callback.  If a header from the enum
 * list below is absent, .token = NULL and len = 0.  Otherwise .token
 * points to .len chars containing that header content.
 */
struct lws_tokens {
	unsigned char *token; /**< pointer to start of the token */
	int len; /**< length of the token's value */
};

/* enum lws_token_indexes
 * these have to be kept in sync with lextable.h / minilex.c
 *
 * NOTE: These public enums are part of the abi.  If you want to add one,
 * add it at where specified so existing users are unaffected.
 */
enum lws_token_indexes {
	WSI_TOKEN_GET_URI, /* 0 */
	WSI_TOKEN_POST_URI,
#if defined(LWS_WITH_HTTP_UNCOMMON_HEADERS) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_OPTIONS_URI,
#endif
	WSI_TOKEN_HOST,
	WSI_TOKEN_CONNECTION,
	WSI_TOKEN_UPGRADE, /* 5 */
	WSI_TOKEN_ORIGIN,
#if defined(LWS_ROLE_WS) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_DRAFT,
#endif
	WSI_TOKEN_CHALLENGE,
#if defined(LWS_ROLE_WS) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_EXTENSIONS,
	WSI_TOKEN_KEY1, /* 10 */
	WSI_TOKEN_KEY2,
	WSI_TOKEN_PROTOCOL,
	WSI_TOKEN_ACCEPT,
	WSI_TOKEN_NONCE,
#endif
	WSI_TOKEN_HTTP,
#if defined(LWS_ROLE_H2) || defined(LWS_ROLE_H3) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_HTTP2_SETTINGS, /* 16 */
#endif
	WSI_TOKEN_HTTP_ACCEPT,
#if defined(LWS_WITH_HTTP_UNCOMMON_HEADERS) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_HTTP_AC_REQUEST_HEADERS,
#endif
	WSI_TOKEN_HTTP_IF_MODIFIED_SINCE,
	WSI_TOKEN_HTTP_IF_NONE_MATCH, /* 20 */
	WSI_TOKEN_HTTP_ACCEPT_ENCODING,
	WSI_TOKEN_HTTP_ACCEPT_LANGUAGE,
	WSI_TOKEN_HTTP_PRAGMA,
	WSI_TOKEN_HTTP_CACHE_CONTROL,
	WSI_TOKEN_HTTP_AUTHORIZATION,
	WSI_TOKEN_HTTP_COOKIE,
	WSI_TOKEN_HTTP_CONTENT_LENGTH, /* 27 */
	WSI_TOKEN_HTTP_CONTENT_TYPE,
	WSI_TOKEN_HTTP_DATE,
	WSI_TOKEN_HTTP_RANGE,
#if defined(LWS_WITH_HTTP_UNCOMMON_HEADERS) || defined(LWS_ROLE_H2) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_HTTP_REFERER,
#endif
#if defined(LWS_ROLE_WS) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_KEY,
	WSI_TOKEN_VERSION,
	WSI_TOKEN_SWORIGIN,
#endif
#if defined(LWS_ROLE_H2) || defined(LWS_ROLE_H3) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_HTTP_COLON_AUTHORITY,
	WSI_TOKEN_HTTP_COLON_METHOD,
	WSI_TOKEN_HTTP_COLON_PATH,
	WSI_TOKEN_HTTP_COLON_SCHEME,
	WSI_TOKEN_HTTP_COLON_STATUS,
#endif

#if defined(LWS_WITH_HTTP_UNCOMMON_HEADERS) || defined(LWS_ROLE_H2) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_HTTP_ACCEPT_CHARSET,
#endif
	WSI_TOKEN_HTTP_ACCEPT_RANGES,
#if defined(LWS_WITH_HTTP_UNCOMMON_HEADERS) || defined(LWS_ROLE_H2) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_HTTP_ACCESS_CONTROL_ALLOW_ORIGIN,
#endif
	WSI_TOKEN_HTTP_AGE,
	WSI_TOKEN_HTTP_ALLOW,
	WSI_TOKEN_HTTP_CONTENT_DISPOSITION,
	WSI_TOKEN_HTTP_CONTENT_ENCODING,
	WSI_TOKEN_HTTP_CONTENT_LANGUAGE,
	WSI_TOKEN_HTTP_CONTENT_LOCATION,
	WSI_TOKEN_HTTP_CONTENT_RANGE,
	WSI_TOKEN_HTTP_ETAG,
	WSI_TOKEN_HTTP_EXPECT,
	WSI_TOKEN_HTTP_EXPIRES,
	WSI_TOKEN_HTTP_FROM,
	WSI_TOKEN_HTTP_IF_MATCH,
	WSI_TOKEN_HTTP_IF_RANGE,
	WSI_TOKEN_HTTP_IF_UNMODIFIED_SINCE,
	WSI_TOKEN_HTTP_LAST_MODIFIED,
	WSI_TOKEN_HTTP_LINK,
	WSI_TOKEN_HTTP_LOCATION,
#if defined(LWS_WITH_HTTP_UNCOMMON_HEADERS) || defined(LWS_ROLE_H2) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_HTTP_MAX_FORWARDS,
	WSI_TOKEN_HTTP_PROXY_AUTHENTICATE,
	WSI_TOKEN_HTTP_PROXY_AUTHORIZATION,
#endif
	WSI_TOKEN_HTTP_REFRESH,
	WSI_TOKEN_HTTP_RETRY_AFTER,
	WSI_TOKEN_HTTP_SERVER,
	WSI_TOKEN_HTTP_SET_COOKIE,
#if defined(LWS_WITH_HTTP_UNCOMMON_HEADERS) || defined(LWS_ROLE_H2) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_HTTP_STRICT_TRANSPORT_SECURITY,
#endif
	WSI_TOKEN_HTTP_TRANSFER_ENCODING,
#if defined(LWS_WITH_HTTP_UNCOMMON_HEADERS) || defined(LWS_ROLE_H2) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_HTTP_USER_AGENT,
	WSI_TOKEN_HTTP_VARY,
	WSI_TOKEN_HTTP_VIA,
	WSI_TOKEN_HTTP_WWW_AUTHENTICATE,
#endif
#if defined(LWS_WITH_HTTP_UNCOMMON_HEADERS) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_PATCH_URI,
	WSI_TOKEN_PUT_URI,
	WSI_TOKEN_DELETE_URI,
#endif

	WSI_TOKEN_HTTP_URI_ARGS,
#if defined(LWS_WITH_HTTP_UNCOMMON_HEADERS) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_PROXY,
	WSI_TOKEN_HTTP_X_REAL_IP,
#endif
	WSI_TOKEN_HTTP1_0,
	WSI_TOKEN_X_FORWARDED_FOR,
	WSI_TOKEN_CONNECT,
	WSI_TOKEN_HEAD_URI,
#if defined(LWS_WITH_HTTP_UNCOMMON_HEADERS) || defined(LWS_ROLE_H2) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_TE,
	WSI_TOKEN_REPLAY_NONCE, /* ACME */
#endif
#if defined(LWS_ROLE_H2) || defined(LWS_ROLE_H3) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_COLON_PROTOCOL,
#endif
	WSI_TOKEN_X_AUTH_TOKEN,
	WSI_TOKEN_DSS_SIGNATURE,

	/****** add new things just above ---^ ******/

	/* use token storage to stash these internally, not for
	 * user use */

	_WSI_TOKEN_CLIENT_SENT_PROTOCOLS,
	_WSI_TOKEN_CLIENT_PEER_ADDRESS,
	_WSI_TOKEN_CLIENT_URI,
	_WSI_TOKEN_CLIENT_HOST,
	_WSI_TOKEN_CLIENT_ORIGIN,
	_WSI_TOKEN_CLIENT_METHOD,
	_WSI_TOKEN_CLIENT_IFACE,
	_WSI_TOKEN_CLIENT_LOCALPORT,
	_WSI_TOKEN_CLIENT_ALPN,

	/* always last real token index*/
	WSI_TOKEN_COUNT,

	/* parser state additions, no storage associated */
	WSI_TOKEN_NAME_PART,
#if defined(LWS_WITH_CUSTOM_HEADERS) || defined(LWS_HTTP_HEADERS_ALL)
	WSI_TOKEN_UNKNOWN_VALUE_PART,
#endif
	WSI_TOKEN_SKIPPING,
	WSI_TOKEN_SKIPPING_SAW_CR,
	WSI_PARSING_COMPLETE,
	WSI_INIT_TOKEN_MUXURL,
};

struct lws_token_limits {
	unsigned short token_limit[WSI_TOKEN_COUNT]; /**< max chars for this token */
};

enum lws_h2_settings {
	H2SET_HEADER_TABLE_SIZE = 1,
	H2SET_ENABLE_PUSH,
	H2SET_MAX_CONCURRENT_STREAMS,
	H2SET_INITIAL_WINDOW_SIZE,
	H2SET_MAX_FRAME_SIZE,
	H2SET_MAX_HEADER_LIST_SIZE,
	H2SET_RESERVED7,
	H2SET_ENABLE_CONNECT_PROTOCOL, /* defined in mcmanus-httpbis-h2-ws-02 */

	H2SET_COUNT /* always last */
};

/**
 * lws_token_to_string() - returns a textual representation of a hdr token index
 *
 * \param token: token index
 */
LWS_VISIBLE LWS_EXTERN const unsigned char *
lws_token_to_string(enum lws_token_indexes token);

/**
 * lws_hdr_total_length: report length of all fragments of a header totalled up
 *		The returned length does not include the space for a
 *		terminating '\0'
 *
 * \param wsi: websocket connection
 * \param h: which header index we are interested in
 */
LWS_VISIBLE LWS_EXTERN int LWS_WARN_UNUSED_RESULT
lws_hdr_total_length(struct lws *wsi, enum lws_token_indexes h);

/**
 * lws_hdr_extant: check if a header is present
 *
 * \param wsi: websocket connection
 * \param h: which header index we are interested in
 */
LWS_VISIBLE LWS_EXTERN int LWS_WARN_UNUSED_RESULT
lws_hdr_extant(struct lws *wsi, enum lws_token_indexes h);

/**
 * lws_hdr_fragment_length: report length of a single fragment of a header
 *		The returned length does not include the space for a
 *		terminating '\0'
 *
 * \param wsi: websocket connection
 * \param h: which header index we are interested in
 * \param frag_idx: which fragment of h we want to get the length of
 */
LWS_VISIBLE LWS_EXTERN int LWS_WARN_UNUSED_RESULT
lws_hdr_fragment_length(struct lws *wsi, enum lws_token_indexes h,
			int frag_idx);

/**
 * lws_hdr_copy() - copy all fragments of the given header to a buffer
 *		The buffer length len must include space for an additional
 *		terminating '\0', or it will fail returning -1.
 *
 * \param wsi: websocket connection
 * \param dest: destination buffer
 * \param len: length of destination buffer
 * \param h: which header index we are interested in
 *
 * copies the whole, aggregated header, even if it was delivered in
 * several actual headers piece by piece.  Returns -1 or length of the whole
 * header.
 */
LWS_VISIBLE LWS_EXTERN int
lws_hdr_copy(struct lws *wsi, char *dest, int len, enum lws_token_indexes h);

/**
 * lws_hdr_copy_fragment() - copy a single fragment of the given header to a buffer
 *		The buffer length len must include space for an additional
 *		terminating '\0', or it will fail returning -2.
 *		If the requested fragment index is not present, it fails
 *		returning -1.
 *
 * \param wsi: websocket connection
 * \param dest: destination buffer
 * \param len: length of destination buffer
 * \param h: which header index we are interested in
 * \param frag_idx: which fragment of h we want to copy
 *
 * Normally this is only useful
 * to parse URI arguments like ?x=1&y=2, token index WSI_TOKEN_HTTP_URI_ARGS
 * fragment 0 will contain "x=1" and fragment 1 "y=2"
 */
LWS_VISIBLE LWS_EXTERN int
lws_hdr_copy_fragment(struct lws *wsi, char *dest, int len,
		      enum lws_token_indexes h, int frag_idx);

/**
 * lws_hdr_custom_length() - return length of a custom header
 *
 * \param wsi: websocket connection
 * \param name: header string (including terminating :)
 * \param nlen: length of name
 *
 * Lws knows about 100 common http headers, and parses them into indexes when
 * it recognizes them.  When it meets a header that it doesn't know, it stores
 * the name and value directly, and you can look them up using
 * lws_hdr_custom_length() and lws_hdr_custom_copy().
 *
 * This api returns -1, or the length of the value part of the header if it
 * exists.  Lws must be built with LWS_WITH_CUSTOM_HEADERS (on by default) to
 * use this api.
 */
LWS_VISIBLE LWS_EXTERN int
lws_hdr_custom_length(struct lws *wsi, const char *name, int nlen);

/**
 * lws_hdr_custom_copy() - copy value part of a custom header
 *
 * \param wsi: websocket connection
 * \param dst: pointer to buffer to receive the copy
 * \param len: number of bytes available at dst
 * \param name: header string (including terminating :)
 * \param nlen: length of name
 *
 * Lws knows about 100 common http headers, and parses them into indexes when
 * it recognizes them.  When it meets a header that it doesn't know, it stores
 * the name and value directly, and you can look them up using
 * lws_hdr_custom_length() and lws_hdr_custom_copy().
 *
 * This api returns -1, or the length of the string it copied into dst if it
 * was big enough to contain both the string and an extra terminating NUL. Lws
 * must be built with LWS_WITH_CUSTOM_HEADERS (on by default) to use this api.
 */
LWS_VISIBLE LWS_EXTERN int
lws_hdr_custom_copy(struct lws *wsi, char *dst, int len, const char *name,
		    int nlen);

typedef void (*lws_hdr_custom_fe_cb_t)(const char *name, int nlen, void *opaque);
/**
 * lws_hdr_custom_name_foreach() - Iterate the custom header names
 *
 * \param wsi: websocket connection
 * \param cb: callback for each custom header name
 * \param opaque: ignored by lws except to pass to callback
 *
 * Lws knows about 100 common http headers, and parses them into indexes when
 * it recognizes them.  When it meets a header that it doesn't know, it stores
 * the name and value directly, and you can look them up using
 * lws_hdr_custom_length() and lws_hdr_custom_copy().
 * 
 * This api returns -1 on error else 0. Use lws_hdr_custom_copy() to get the
 * values of headers. Lws must be built with LWS_WITH_CUSTOM_HEADERS (on by
 * default) to use this api.
 */
LWS_VISIBLE LWS_EXTERN int
lws_hdr_custom_name_foreach(struct lws *wsi, lws_hdr_custom_fe_cb_t cb, void *opaque);

/**
 * lws_get_urlarg_by_name_safe() - get copy and return length of y for x=y urlargs
 *
 * \param wsi: the connection to check
 * \param name: the arg name to look for.  Including the trailing '=' is
 *              recommended (eg "token="); if you omit it, a single '=' separator
 *              in the matched arg is still trimmed from the result for you
 * \param buf: the buffer to receive the urlarg *value* (the name= prefix is
 *             not copied).  It only needs to be large enough for the value you
 *             want back, plus the NUL terminator -- the name= prefix match is
 *             done against the in-place parsed header storage and does not
 *             depend on the size of buf
 * \param len: the usable size of buf in bytes
 *
 * Looks up the URI query arg "name" (from the request's ?... part) and copies
 * its value into buf.
 *
 * Urlarg values may be fragmented in the parsed-header storage when the request
 * line contains multiple ?x=y&w=z style args; this helper walks the full arg
 * fragment chain to find the named one, so the buf size has no effect on which
 * arg is matched -- only on whether the matched value fits.
 *
 * Returns one of:
 *
 *   >= 0: the arg was present and its value (length \p return_value, NUL not
 *         included) is in buf, with a NUL written at buf[return_value].  A
 *         returned length of 0 means the arg was given as a bare "name=" with
 *         an empty value
 *   -1:    the arg was not present, or there is no parsed header storage
 *   -2:    the arg was found but its value will not fit in buf (len bytes,
 *         including room for the NUL); buf is left unmodified.  Call again with
 *         a larger buf if you need the value
 *
 * The parser refuses any request whose URI contains a C0 control byte or
 * DEL (raw or percent-encoded), so the returned value only ever contains
 * printable and high (>= 0x80, eg UTF-8) bytes.
 *
 * This returns the explicit length and so can deal with values that are
 * percent-encoded (the parser already percent-decodes the URI-args before they
 * reach here).  It always writes a NUL just after the valid length so the
 * result can also be used with NUL-based apis when you don't care about
 * truncation.
 *
 * buf may have been written even when -1 is returned indicating no match.
 *
 * Use this in place of lws_get_urlarg_by_name() that does not return an
 * explicit length.
 */
LWS_VISIBLE LWS_EXTERN int
lws_get_urlarg_by_name_safe(struct lws *wsi, const char *name, char *buf, int len);

/**
 * lws_get_urlarg_by_name() - return pointer to arg value if present
 *
 * \param wsi: the connection to check
 * \param name: the arg name, like "token="
 * \param buf: the buffer to receive the urlarg *value* (the name= prefix is
 *             not returned); it only needs to be large enough for the value
 *             you want back, plus the NUL terminator
 * \param len: the usable size of buf in bytes
 *
 *     Returns NULL if not found (or if the value did not fit in buf), or a
 *     pointer to buf holding just the value (NUL-terminated).
 *
 * This assumed the argument can be represented with a NUL-terminated string.
 * It can't correctly deal with binary values encoded with %XX, eg. %00 will
 * be understood to terminate the string.
 *
 * Use lws_get_urlarg_by_name_safe() instead of this, which returns the length
 * and distinguishes "not present" (-1) from "did not fit" (-2).
 */
LWS_VISIBLE LWS_EXTERN const char *
lws_get_urlarg_by_name(struct lws *wsi, const char *name, char *buf, int len)
/* LWS_WARN_DEPRECATED */;

/**
 * lws_http_remove_urlarg() - remove a named urlarg from the header table
 *
 * \param wsi: the connection to check
 * \param name: the arg name to remove, eg "token" or "token="
 *
 * This removes the named argument from the WSI_TOKEN_HTTP_URI_ARGS fragment
 * chain in the header table (ah).  It does not reclaim space in the ah data
 * area, but the argument will no longer be visible to subsequent protocols
 * handling the same wsi.
 *
 * Returns 0 if removed, else nonzero.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_remove_urlarg(struct lws *wsi, const char *name);

/**
 * lws_http_log_path() - render a url or request path for a log line
 *
 * \param buf: the buffer to render into
 * \param len: the usable size of buf in bytes, including the NUL
 * \param path: the url or path to render, or NULL
 *
 * Query strings commonly carry credentials (OAuth code= and state=, presigned
 * URL signatures, ?api_key=...), and logs outlive the connection and reach a
 * wider audience than the url's owner.  So a log line showing a url or path,
 * sent or received, should show it through this: it is copied cut at the
 * first '?', truncated to fit, with control and non-ASCII bytes shown as '.'
 * so it cannot forge log lines.
 *
 * Returns buf, always NUL-terminated, or "NULL" if path is NULL.
 */
LWS_VISIBLE LWS_EXTERN const char *
lws_http_log_path(char *buf, size_t len, const char *path);

/**
 * lws_http_zap_header() - remove a named header from the header table
 *
 * \param wsi: the connection to check
 * \param name: the header name to remove, eg "X-Auth-User"
 *
 * This removes the named header from the header table (ah). It handles both
 * recognized tokens and unknown custom headers. Note that it does not reclaim
 * space in the ah data area, but the header will no longer be visible to
 * subsequent protocols or forwarded during proxying.
 *
 * Returns 0 if removed or not found, else nonzero.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_zap_header(struct lws *wsi, const char *name);

/**
 * lws_http_add_onward_header() - add a header to be forwarded to the proxy
 *                                  backend
 *
 * \param wsi: the connection (typically the browser-side wsi an interceptor
 *             sees during LWS_CALLBACK_HTTP_INTERCEPTOR_CHECK)
 * \param name: the header name, eg "x-lws-login-admin"
 * \param value: the header value (NUL-terminated)
 *
 * Interceptors authenticate the request and may want to pass the cooked,
 * trusted result (eg logged-in subject, admin flag) to the backend app served
 * behind a reverse-proxy mount, so the app does no auth of its own.  This
 * appends "name: value\r\n" to the wsi's "extra onward headers" blob, which
 * the HTTP and WS proxy paths forward to the backend.
 *
 * To prevent spoofing, any client-supplied copy of the same header is
 * removed from the request headers (as by lws_http_zap_header()) before the
 * trusted one is appended, so it cannot reach the backend or be read from
 * the ah by anything downstream.  An interceptor that decides NOT to stamp
 * a header it normally would (eg, it refused the request, or waved it
 * through on some bypass) should still lws_http_zap_header() it, so the
 * peer's copy is gone on every path.
 *
 * Returns 0 on success or nonzero on OOM.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_add_onward_header(struct lws *wsi, const char *name,
			   const char *value);

/**
 * lws_http_get_onward_header() - read a header an interceptor stamped on
 *				  this request
 *
 * \param wsi: the connection, during the request (LWS_CALLBACK_HTTP etc)
 * \param name: the header name, eg LWS_LOGIN_HDR_STATE
 * \param buf: receives the value, NUL terminated
 * \param len: size of buf
 *
 * The counterpart of lws_http_add_onward_header() for an app served
 * IN-PROCESS behind a gated mount, rather than through the reverse proxy.
 * The proxy forwards the stamped headers to a remote backend as request
 * headers; an in-process protocol handling the same request gets them from
 * here instead.  Only an interceptor can put something in this list (the
 * peer's own copy of the name is removed from the request when it is
 * stamped), so unlike a header read from the request, the value is
 * trustworthy without any "is there a proxy in front of me" configuration.
 *
 * Returns the value length, -1 if nothing of that name was stamped, or -2
 * if the value does not fit in buf.  Reads the transaction's state, so it
 * must be called while the request is being handled, not from a later
 * timer.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_get_onward_header(struct lws *wsi, const char *name, char *buf,
			   size_t len);

///@}

/*! \defgroup lws-login-state Login state injection (lws-login)
 * \ingroup http
 *
 * ## Login state injection
 *
 * When a mount is guarded by the `lws-login` bouncer plugin, the bouncer
 * authenticates the request, decides the requestor's role from the verified
 * JWT grants, and stamps the cooked, trusted result onto the browser-side wsi
 * as "extra onward headers" (set with lws_http_add_onward_header(), which
 * first anti-spoofs any client-supplied copy; the bouncer also snips them on
 * every path through its check, stamped or not).  The HTTP/WS
 * proxy paths then forward these to the backend app behind the mount, so the
 * app does no JWT/grant work of its own -- it just reads the headers.
 *
 * The authoritative summary is the single header \ref LWS_LOGIN_HDR_STATE,
 * whose value is the stringified \ref lws_login_state.  The finer-grained
 * \ref LWS_LOGIN_HDR_GRANT_LEVEL (the raw integer grant level the bouncer used
 * to decide the role for this mount) and \ref LWS_LOGIN_HDR_SUB (the subject
 * identity) are also injected for apps that want the detail.  \ref
 * LWS_LOGIN_HDR_ADMIN is kept for back-compat and is exactly equivalent to
 * `state == LWS_LOGIN_STATE_GLOBAL_ADMIN`.
 *
 * The state, and the grant level, are about one service: the one the mount
 * the request arrived on names in its "service-name".  \ref
 * LWS_LOGIN_HDR_SERVICE says which, so a backend serving more than one mount,
 * or wanting to be sure the mount it is behind is the one it expects, can
 * check the state is about the grant it cares about.
 *
 * Crucially, \ref LWS_LOGIN_STATE_APP_ADMIN (admin of THIS app only) and \ref
 * LWS_LOGIN_STATE_GLOBAL_ADMIN (the TOFU "*" / "god" account, admin of the
 * whole system) are distinct: a backend must not treat an app admin as a
 * system-wide admin.  The states are strictly ordered by privilege, so
 * `state >= LWS_LOGIN_STATE_APP_ADMIN` selects "any kind of admin" and
 * `state == LWS_LOGIN_STATE_GLOBAL_ADMIN` selects "system-wide only".
 *
 * These headers are only trustworthy when they reach the backend through the
 * bouncer's proxy path: the bouncer zaps any client-supplied copy first.  A
 * backend reachable directly (bypassing the mount) must not trust them.
 */
///@{
#define LWS_LOGIN_HDR_STATE        "x-lws-login-state"
#define LWS_LOGIN_HDR_ADMIN        "x-lws-login-admin"
#define LWS_LOGIN_HDR_GRANT_LEVEL  "x-lws-login-grant-level"
#define LWS_LOGIN_HDR_SUB          "x-lws-login-sub"
#define LWS_LOGIN_HDR_SERVICE      "x-lws-login-service"

/**
 * enum lws_login_state - summary role of the identity reaching a backend
 *
 * Value of \ref LWS_LOGIN_HDR_STATE as injected by the lws-login bouncer into
 * backend apps behind a protected mount.  Members are ordered by privilege;
 * higher == strictly more authority.
 */
enum lws_login_state {
	/** No valid JWT.  Only observable on mounts with unauth-allow=1. */
	LWS_LOGIN_STATE_ANON = 0,
	/** Valid JWT, but no grant (and no "*" wildcard) for this service. */
	LWS_LOGIN_STATE_NO_GRANT = 1,
	/** Holds this service's grant at level >= 1 but < 2, no "*". */
	LWS_LOGIN_STATE_USER = 2,
	/** Holds this service's grant at level >= 2, no "*": admin of THIS
	 * app only, NOT a system-wide admin. */
	LWS_LOGIN_STATE_APP_ADMIN = 3,
	/** Holds the "*" wildcard grant (the TOFU "god" account): admin of the
	 * whole system.  Any "*" level >= 1 qualifies. */
	LWS_LOGIN_STATE_GLOBAL_ADMIN = 4,
};

/**
 * LWS_LOGIN_CALLBACK_SESSION_LIVE - ask lws-login if a request has a session
 *
 * Another protocol on the same vhost (eg, an interceptor that wants to wave
 * logged-in users through) calls the vhost's "lws-login" protocol callback
 * with this reason, user and in NULL and len 0, on the wsi of the request it
 * is handling.  It returns 0 only if the request carries an authentic,
 * unexpired lws-login session, still backed by the auth server's records,
 * holding at least the vhost's minimum grant level for the service the
 * request's mount names; nonzero otherwise.
 *
 * Unlike LWS_CALLBACK_HTTP_INTERCEPTOR_CHECK, which returns 0 for anything it
 * lets through, an anonymous request lws-login would let through on an
 * unauth-allow vhost or mount is not a session, and gets nonzero.  It has no
 * side effects on the request: nothing is stamped or snipped.
 */
#define LWS_LOGIN_CALLBACK_SESSION_LIVE	(LWS_CALLBACK_USER + 1)
///@}

/*! \defgroup HTTP-headers-create HTTP headers: create
 *
 * ## HTTP headers: Create
 *
 * These apis allow you to create HTTP response headers in a way compatible with
 * both HTTP/1.x and HTTP/2.
 *
 * They each append to a buffer taking care about the buffer end, which is
 * passed in as a pointer.  When data is written to the buffer, the current
 * position p is updated accordingly.
 *
 * All of these apis are LWS_WARN_UNUSED_RESULT as they can run out of space
 * and fail with nonzero return.
 */
///@{

#define LWSAHH_CODE_MASK			((1 << 16) - 1)
#define LWSAHH_FLAG_NO_SERVER_NAME		(1 << 30)

/**
 * lws_add_http_header_status() - add the HTTP response status code
 *
 * \param wsi: the connection to check
 * \param code: an HTTP code like 200, 404 etc (see enum http_status)
 * \param p: pointer to current position in buffer pointer
 * \param end: pointer to end of buffer
 *
 * Adds the initial response code, so should be called first.
 *
 * Code may additionally take OR'd flags:
 *
 *    LWSAHH_FLAG_NO_SERVER_NAME:  don't apply server name header this time
 */
LWS_VISIBLE LWS_EXTERN int LWS_WARN_UNUSED_RESULT
lws_add_http_header_status(struct lws *wsi,
			   unsigned int code, unsigned char **p,
			   unsigned char *end);
/**
 * lws_add_http_header_by_name() - append named header and value
 *
 * \param wsi: the connection to check
 * \param name: the hdr name, like "my-header:"
 * \param value: the value after the = for this header
 * \param length: the length of the value
 * \param p: pointer to current position in buffer pointer
 * \param end: pointer to end of buffer
 *
 * Appends name: value to the headers
 *
 * The add fails (returns 1, nothing emitted) if the name or the value
 * contains a C0 control byte other than TAB, or DEL: header values are
 * RFC 9110 field-content (VCHAR / SP / HTAB / obs-text), and emitting
 * such bytes is at best invalid and at worst response splitting over
 * h1.  This also fences misconfiguration (CR/LF in vhost header strings).
 *
 * A NULL name composes the value with no field name (used for the h1
 * status line); h2/h3 have no such representation (the status is the
 * :status pseudo-header from the _status helpers), so over h2/h3 a NULL
 * name fails the add (returns 1, nothing emitted).
 *
 * A header that does not fit before \p end also fails the add, and leaves
 * nothing of itself behind: *p is where it was before the call, so the
 * caller may go on to add something smaller, or fail its own composition.
 */
LWS_VISIBLE LWS_EXTERN int LWS_WARN_UNUSED_RESULT
lws_add_http_header_by_name(struct lws *wsi, const unsigned char *name,
			    const unsigned char *value, int length,
			    unsigned char **p, unsigned char *end);
/**
 * lws_add_http_header_by_token() - append given header and value
 *
 * \param wsi: the connection to check
 * \param token: the token index for the hdr
 * \param value: the value after the = for this header
 * \param length: the length of the value
 * \param p: pointer to current position in buffer pointer
 * \param end: pointer to end of buffer
 *
 * Appends name=value to the headers, but is able to take advantage of better
 * HTTP/2 coding mechanisms where possible.
 *
 * As with lws_add_http_header_by_name(), the add fails (returns 1, nothing
 * emitted) if the value contains a C0 control byte other than TAB, or DEL.
 */
LWS_VISIBLE LWS_EXTERN int LWS_WARN_UNUSED_RESULT
lws_add_http_header_by_token(struct lws *wsi, enum lws_token_indexes token,
			     const unsigned char *value, int length,
			     unsigned char **p, unsigned char *end);
/**
 * lws_add_http_header_content_length() - append content-length helper
 *
 * \param wsi: the connection to check
 * \param content_length: the content length to use
 * \param p: pointer to current position in buffer pointer
 * \param end: pointer to end of buffer
 *
 * Appends content-length: content_length to the headers
 */
LWS_VISIBLE LWS_EXTERN int LWS_WARN_UNUSED_RESULT
lws_add_http_header_content_length(struct lws *wsi,
				   lws_filepos_t content_length,
				   unsigned char **p, unsigned char *end);
/**
 * lws_finalize_http_header() - terminate header block
 *
 * \param wsi: the connection to check
 * \param p: pointer to current position in buffer pointer
 * \param end: pointer to end of buffer
 *
 * Indicates no more headers will be added
 */
LWS_VISIBLE LWS_EXTERN int LWS_WARN_UNUSED_RESULT
lws_finalize_http_header(struct lws *wsi, unsigned char **p,
			 unsigned char *end);

/**
 * lws_finalize_write_http_header() - Helper finalizing and writing http headers
 *
 * \param wsi: the connection to check
 * \param start: pointer to the start of headers in the buffer, eg &buf[LWS_PRE]
 * \param p: pointer to current position in buffer pointer
 * \param end: pointer to end of buffer
 *
 * Terminates the headers correctly according to the protocol in use (h1 / h2)
 * and writes the headers.  Returns nonzero for error.
 *
 * This is a convenience wrapper around lws_finalize_write_http_header_flags()
 * (declared in lws-write.h, alongside the write-protocol enum) that passes
 * plain LWS_WRITE_HTTP_HEADERS, suitable for responses that will send a body
 * afterwards.  For a headers-only response (eg a 302 with no body), use
 * lws_finalize_write_http_header_flags() with
 * LWS_WRITE_HTTP_HEADERS | LWS_WRITE_H2_STREAM_END so that under h2 / h3 the
 * HEADERS frame carries END_STREAM -- otherwise the stream hangs open waiting
 * for a body that never comes and the client sees no response.
 */
LWS_VISIBLE LWS_EXTERN int LWS_WARN_UNUSED_RESULT
lws_finalize_write_http_header(struct lws *wsi, unsigned char *start,
			       unsigned char **p, unsigned char *end);

#define LWS_ILLEGAL_HTTP_CONTENT_LEN ((lws_filepos_t)-1ll)

/**
 * lws_add_http_common_headers() - Helper preparing common http headers
 *
 * \param wsi: the connection to check
 * \param code: an HTTP code like 200, 404 etc (see enum http_status)
 * \param content_type: the content type, like "text/html"
 * \param content_len: the content length, in bytes
 * \param p: pointer to current position in buffer pointer
 * \param end: pointer to end of buffer
 *
 * Adds the initial response code, so should be called first.
 *
 * Code may additionally take OR'd flags:
 *
 *    LWSAHH_FLAG_NO_SERVER_NAME:  don't apply server name header this time
 *
 * This helper just calls public apis to simplify adding headers that are
 * commonly needed.  If it doesn't fit your case, or you want to add additional
 * headers just call the public apis directly yourself for what you want.
 *
 * You can miss out the content length header by providing the constant
 * LWS_ILLEGAL_HTTP_CONTENT_LEN for the content_len.
 *
 * It does not call lws_finalize_http_header(), to allow you to add further
 * headers after calling this.  You will need to call that yourself at the end.
 */
LWS_VISIBLE LWS_EXTERN int LWS_WARN_UNUSED_RESULT
lws_add_http_common_headers(struct lws *wsi, unsigned int code,
			    const char *content_type, lws_filepos_t content_len,
			    unsigned char **p, unsigned char *end);

enum {
	LWSHUMETH_GET,
	LWSHUMETH_POST,
	LWSHUMETH_OPTIONS,
	LWSHUMETH_PUT,
	LWSHUMETH_PATCH,
	LWSHUMETH_DELETE,
	LWSHUMETH_CONNECT,
	LWSHUMETH_HEAD,
	LWSHUMETH_COLON_PATH,
};

/**
 * lws_http_get_uri_and_method() - Get information on method and url
 *
 * \param wsi: the connection to get information on
 * \param puri_ptr: points to pointer to set to url
 * \param puri_len: points to int to set to uri length
 *
 * Returns -1 or method index as one of the LWSHUMETH_ constants
 *
 * If returns method, *puri_ptr is set to the method's URI string and *puri_len
 * to its length
 */

LWS_VISIBLE LWS_EXTERN int LWS_WARN_UNUSED_RESULT
lws_http_get_uri_and_method(struct lws *wsi, char **puri_ptr, int *puri_len);

#if defined(LWS_WITH_HTTP_BASIC_AUTH) && defined(LWS_WITH_SERVER)
/**
 * lws_http_basic_auth_user() - the user name basic auth accepted
 *
 * \param wsi: the server connection or stream
 *
 * Returns the user name lws's own basic auth (a mount's
 * "basic-auth" login file or LWSAUTHM_BASIC_AUTH_CALLBACK, or a ws
 * protocol's "basic-auth" pvo) accepted for the request being served, or
 * NULL if it was not authenticated that way.
 *
 * Unlike WSI_TOKEN_HTTP_AUTHORIZATION, which lws also rewrites to the user
 * name, it does not depend on the request headers still being there: it is
 * valid until the transaction completes, or for a ws connection, until it
 * closes.
 */
LWS_VISIBLE LWS_EXTERN const char *
lws_http_basic_auth_user(struct lws *wsi);
#endif

///@}

/*! \defgroup urlendec Urlencode and Urldecode
 * \ingroup http
 *
 * ##HTML chunked Substitution
 *
 * APIs for receiving chunks of text, replacing a set of variable names via
 * a callback, and then prepending and appending HTML chunked encoding
 * headers.
 */
//@{

/**
 * lws_urlencode() - like strncpy but with urlencoding
 *
 * \param escaped: output buffer
 * \param string: input buffer ('/0' terminated)
 * \param len: output buffer max length
 *
 * Because urlencoding expands the output string, it's not
 * possible to do it in-place, ie, with escaped == string
 */
LWS_VISIBLE LWS_EXTERN const char *
lws_urlencode(char *escaped, const char *string, int len);

/*
 * URLDECODE 1 / 2
 *
 * This simple urldecode only operates until the first '\0' and requires the
 * data to exist all at once
 */
/**
 * lws_urldecode() - like strncpy but with urldecoding
 *
 * \param string: output buffer
 * \param escaped: input buffer ('\0' terminated)
 * \param len: output buffer max length
 *
 * This is only useful for '\0' terminated strings
 *
 * Since urldecoding only shrinks the output string, it is possible to
 * do it in-place, ie, string == escaped
 *
 * Returns 0 if completed OK or nonzero for urldecode violation (non-hex chars
 * where hex required, etc)
 */
LWS_VISIBLE LWS_EXTERN int
lws_urldecode(char *string, const char *escaped, int len);
///@}

/**
 * lws_http_date_render_from_unix() - render unixtime as RFC7231 date string
 *
 * \param buf:		Destination string buffer
 * \param len:		avilable length of dest string buffer in bytes
 * \param t:		pointer to the time_t to render
 *
 * Returns 0 if time_t is rendered into the string buffer successfully, else
 * nonzero.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_date_render_from_unix(char *buf, size_t len, const time_t *t);

/**
 * lws_http_date_parse_unix() - parse a RFC7231 date string into unixtime
 *
 * \param b:		Source string buffer
 * \param len:		avilable length of source string buffer in bytes
 * \param t:		pointer to the destination time_t to set
 *
 * Returns 0 if string buffer parsed as RFC7231 time successfully, and
 * *t set to the parsed unixtime, else return nonzero.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_date_parse_unix(const char *b, size_t len, time_t *t);

/**
 * lws_http_check_retry_after() - increase a timeout if retry-after present
 *
 * \param wsi:		http stream this relates to
 * \param us_interval_in_out: default us retry interval on entry may be updated
 *
 * This function may extend the incoming retry interval if the server has
 * requested that using retry-after: header.  It won't reduce the incoming
 * retry interval, only leave it alone or increase it.
 *
 * *us_interval_in_out should be set to a default retry interval on entry, if
 * the wsi has a retry-after time or interval that resolves to an interval
 * longer than the entry *us_interval_in_out, that will be updated to the longer
 * interval and return 0.
 *
 * If no usable retry-after or the time is now or in the past,
 * *us_interval_in_out is left alone and the function returns nonzero.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_check_retry_after(struct lws *wsi, lws_usec_t *us_interval_in_out);

/**
 * lws_return_http_status() - Return simple http status
 * \param wsi:		Websocket instance (available from user callback)
 * \param code:		Status index, eg, 404
 * \param html_body:		User-readable HTML description < 1KB, or NULL
 *
 *	Helper to report HTTP errors back to the client cleanly and
 *	consistently
 */
LWS_VISIBLE LWS_EXTERN int
lws_return_http_status(struct lws *wsi, unsigned int code,
		       const char *html_body);

/**
 * lws_http_redirect() - write http redirect out on wsi
 *
 * \param wsi:	websocket connection
 * \param code:	HTTP response code (eg, 301)
 * \param loc:	where to redirect to
 * \param len:	length of loc
 * \param p:	pointer current position in buffer (updated as we write)
 * \param end:	pointer to end of buffer
 *
 * Returns amount written, or < 0 indicating fatal write failure.
 */
LWS_VISIBLE LWS_EXTERN int LWS_WARN_UNUSED_RESULT
lws_http_redirect(struct lws *wsi, int code, const unsigned char *loc, int len,
		  unsigned char **p, unsigned char *end);

/**
 * lws_http_transaction_completed() - wait for new http transaction or close
 * \param wsi:	websocket connection
 *
 *	Returns nonzero if the HTTP connection must close now
 *	Returns 0 and resets connection to wait for new HTTP header /
 *	  transaction if possible
 */
LWS_VISIBLE LWS_EXTERN int LWS_WARN_UNUSED_RESULT
lws_http_transaction_completed(struct lws *wsi);

/**
 * lws_http_headers_detach() - drop the associated headers storage and allow
 *				it to be reused by another connection
 * \param wsi:	http connection
 *
 * If the wsi has an ah headers struct attached, detach it.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_headers_detach(struct lws *wsi);

/**
 * lws_http_mark_sse() - called to indicate this http stream is now doing SSE
 *
 * \param wsi:	http connection
 *
 * Cancel any timeout on the wsi, and for h2, mark the network connection as
 * containing an immortal stream for the duration the SSE stream is open.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_mark_sse(struct lws *wsi);

/**
 * lws_h2_client_stream_long_poll_rxonly() - h2 stream to immortal read-only
 *
 * \param wsi: h2 stream client wsi
 *
 * Send END_STREAM-flagged zero-length DATA frame to set client stream wsi into
 * half-closed (local) and remote into half-closed (remote).  Set the client
 * stream wsi to be immortal (not subject to timeouts).
 *
 * Used if the remote server supports immortal long poll to put the stream into
 * a read-only state where it can wait as long as needed for rx.
 *
 * Returns 0 if the process (which happens asynchronously) started or non-zero
 * if it wasn't an h2 stream.
 */
LWS_VISIBLE LWS_EXTERN int
lws_h2_client_stream_long_poll_rxonly(struct lws *wsi);

/**
 * lws_http_compression_apply() - apply an http compression transform
 *
 * \param wsi: the wsi to apply the compression transform to
 * \param name: NULL, or the name of the compression transform, eg, "deflate"
 * \param p: pointer to pointer to headers buffer
 * \param end: pointer to end of headers buffer
 * \param decomp: 0 = add compressor to wsi, 1 = add decompressor
 *
 * This allows transparent compression of dynamically generated HTTP.  The
 * requested compression (eg, "deflate") is only applied if the client headers
 * indicated it was supported (and it has support in lws), otherwise it's a NOP.
 *
 * If the requested compression method is NULL, then the supported compression
 * formats are tried, and for non-decompression (server) mode the first that's
 * found on the client's accept-encoding header is chosen.
 *
 * In server mode it also adds "vary: accept-encoding" to the headers, whether
 * or not a compression is applied, since which representation is sent
 * depends on that request header.  Returns -1 if a header did not fit.  On a
 * vhost with LWS_SERVER_OPTION_NO_HTTP_STREAM_COMPRESSION, it's a NOP in
 * server mode.
 *
 * NOTE: the compression transform, same as h2 support, relies on the user
 * code using LWS_WRITE_HTTP and then LWS_WRITE_HTTP_FINAL on the last part
 * written.  The internal lws fileserving code already does this.
 *
 * If the library was built without the cmake option
 * LWS_WITH_HTTP_STREAM_COMPRESSION set, then a NOP is provided for this api,
 * allowing user code to build either way and use compression if available.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_compression_apply(struct lws *wsi, const char *name,
			   unsigned char **p, unsigned char *end, char decomp);

/**
 * lws_http_compression_opt_out() - don't compress this response
 *
 * \param wsi: the server wsi (h1 connection, or h2 / h3 stream) whose response
 *	       must not be compressed
 *
 * In a build with LWS_WITH_HTTP_STREAM_COMPRESSION, lws compresses text-ish
 * responses on the fly when the client accepts it: those composed with
 * lws_add_http_common_headers(), and files served by lws_serve_http_file().
 * A response that carries a secret (a csrf token, a session-bound value)
 * together with anything the client can influence (a reflected parameter)
 * must not be compressed, since the compressed length can leak the secret to
 * an attacker able to make the victim's browser send many requests and watch
 * the size of the TLS records (BREACH).
 *
 * Call this before composing the response headers, eg, at LWS_CALLBACK_HTTP,
 * to send this one response uncompressed: lws_add_http_common_headers(),
 * lws_serve_http_file() and lws_http_compression_apply() then leave it as it
 * is, and it does not say "vary: accept-encoding".  It applies to the response
 * to the current request only, on every role; the next request on the
 * connection is compressed as usual.  To stop a whole vhost compressing, use
 * LWS_SERVER_OPTION_NO_HTTP_STREAM_COMPRESSION instead.  It does not affect a
 * file served from a mount that is already stored gzipped.
 *
 * lws does not decide this for itself from the response's headers, eg, a
 * Set-Cookie or "cache-control: no-store": the coding is chosen when the
 * common headers are composed, before the app adds those, and lws' own file
 * serving says no-store for files on mounts without caching policy.
 *
 * Returns 0, or -1 if it is too late: the response is already being
 * compressed.  If the library was built without
 * LWS_WITH_HTTP_STREAM_COMPRESSION, it's a NOP returning 0.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_compression_opt_out(struct lws *wsi);

/**
 * lws_http_is_redirected_to_get() - true if redirected to GET
 *
 * \param wsi: the wsi to check
 *
 * Check if the wsi is currently in GET mode, after, eg, doing a POST and
 * receiving a 303.  As RFC 9110 15.4 says, a 303 turns any method but HEAD
 * into a GET, a 301 or 302 turns only a POST into a GET, and 307 / 308 keep
 * the method.  When this returns true, the request must not send its body
 * again; when a redirect kept the method, it must send all of it again.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_is_redirected_to_get(struct lws *wsi);

/**
 * lws_http_cookie_get() - return copy of named cookie if present
 *
 * \param wsi: the wsi to check
 * \param name: name of the cookie
 * \param buf: buffer to store the cookie contents into
 * \param max: on entry, maximum length of buf... on exit, used len of buf
 *
 * If no cookie header, or no cookie of the requested name, returns 1.  If the
 * value, with its terminating NUL, is larger than can fit in buf, returns 2.
 * In those cases, buf and *max are untouched: a partial value is never handed
 * out.
 *
 * If the cookie is found, copies its whole value into buf with a terminating
 * NUL, sets *max to the used length, and returns 0.
 *
 * The Cookie header(s) are parsed as a list of name=value cookie-pairs
 * separated by ';', so a name only matches at the start of a pair, never a
 * "name=" appearing inside another cookie's value.  The name and the value
 * have any surrounding whitespace trimmed; the value is otherwise returned as
 * it was sent.  It is the same as lws_http_cookie_get_nth() with \p n of 0:
 * the first occurrence of exactly \p name.
 *
 * No aliases of \p name are tried.  To read a cookie set as "__Host-x" or
 * "__Secure-x", ask for that full name; asking for "x" only finds a cookie
 * literally named "x".  The prefix is the browser's guarantee about who could
 * set the cookie, so a lookup must not let a bare-named cookie, which any
 * sibling host under the registrable domain can set, stand in for it.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_cookie_get(struct lws *wsi, const char *name, char *buf, size_t *max);

/**
 * lws_http_cookie_get_nth() - return copy of the n-th same-named cookie
 *
 * \param wsi: the wsi to check
 * \param name: name of the cookie
 * \param n: the 0-based occurrence of the cookie to fetch
 * \param buf: buffer to store the cookie contents into
 * \param max: on entry, maximum length of buf... on exit, used len of buf
 *
 * Browsers can legitimately present multiple cookies with the same name (eg a
 * host-only cookie alongside a Domain-scoped one set by a different flow), and
 * RFC 6265 orders same-path cookies oldest-first.  This lets credential
 * resolution walk every value with n = 0, 1, ... rather than trusting that the
 * first one is the live one.
 *
 * If no n-th cookie of the requested name exists, returns 1.  If the value,
 * with its terminating NUL, is larger than can fit in buf, returns 2.  In
 * those cases, buf and *max are untouched: a partial value is never handed
 * out.  Otherwise copies the whole value into buf with a terminating NUL,
 * sets *max to the used length, and returns 0.
 *
 * As for lws_http_cookie_get(), no __Host- / __Secure- prefixed aliases of the
 * name are considered; exactly \p name is resolved.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_cookie_get_nth(struct lws *wsi, const char *name, int n,
			char *buf, size_t *max);

/**
 * lws_http_cookie_compose() - compose a complete set-cookie: header value
 *
 * \param buf: buffer to compose the header value into, or NULL to only measure
 * \param len: bytes available at buf; ignored when buf is NULL
 * \param name: cookie name; must be non-NULL (use "" never to clear)
 * \param value: cookie value; must be non-NULL ("" for a clearing cookie)
 * \param domain: optional Domain attribute; NULL or "" for a host-only cookie
 * \param max_age: Max-Age attribute, seconds (0 when clearing)
 * \param expires: optional Expires attribute (RFC 1123 date string), or NULL
 *
 * Composes "name=value; Path=/; [Domain=..; ][Expires=..; ]Max-Age=N;
 * HttpOnly; SameSite=Lax; Secure" -- the fixed scoping the lws SSO plugins
 * mint their session cookies with -- into buf, ready to pass to
 * lws_add_http_header_by_name() as a set-cookie: value.
 *
 * The attribute tail is never silently truncated: a Set-Cookie whose
 * HttpOnly / SameSite / Secure attributes were chopped off is
 * browser-readable and http-sendable, exactly what the attribute tail exists
 * to prevent.  If the complete string with its full attribute set does not
 * fit in buf, nothing is composed, buf[0] is set to '\0' (when buf and len
 * are usable) and -1 is returned; callers must fail the response or skip the
 * cookie, never emit the partial string.
 *
 * With buf set to NULL, returns the length the composed string would have
 * (excluding the terminating NUL), so callers can size a buffer first.
 *
 * Returns the length of the composed string in buf (excluding the NUL), or
 * -1 if it would not fit / the arguments are unusable.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_cookie_compose(char *buf, size_t len, const char *name,
			const char *value, const char *domain,
			unsigned long long max_age, const char *expires);

#define LWS_HOC_REQUIRE_ORIGIN		(1u << 0)
/**< lws_http_origin_check(): refuse a request with no Origin header */

/**
 * lws_http_origin_check() - is a request from a page of this same authority
 *
 * \param wsi: the server wsi of an http request or ws upgrade, while its
 *	       request headers are still available
 * \param allow: NULL, or a comma-separated list of further complete origins
 *		 to accept, eg "https://a.example.com,https://b.example.com:8443"
 * \param flags: LWS_HOC_REQUIRE_ORIGIN to refuse a request without Origin
 *
 * A ws upgrade is exempt from the same-origin policy, and a form POST is a
 * CORS "simple request": both are sent with the browser's cookies whatever
 * page caused them, and SameSite=Lax does not stop a page on a same-site host
 * (a sibling subdomain) from sending a Lax cookie.  So a ws or a POST that is
 * authorized by an ambient credential, such as a session cookie, must also
 * check that the request came from a page of its own: call this from
 * LWS_CALLBACK_FILTER_PROTOCOL_CONNECTION, or before acting on the POST.
 *
 * The Origin must be https://<the authority the request was sent to> (Host on
 * h1, :authority on h2 / h3), compared case-insensitively, or be listed in
 * \p allow.  On a connection that is not itself TLS, http://<authority> is
 * accepted too, since a TLS-terminating proxy in front looks the same as a
 * plain http deployment.  "null" (sent by sandboxed documents) never matches,
 * and an Origin header that is repeated or too long to be a real origin is
 * refused.
 *
 * Browsers always send Origin on a ws upgrade and on a POST, so a request
 * without one is from a non-browser client, which carries no ambient
 * credential problem; it is accepted unless \p flags has
 * LWS_HOC_REQUIRE_ORIGIN.
 *
 * Returns 0 if the request may proceed, nonzero to refuse it, which includes
 * when the request headers are no longer available.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_origin_check(struct lws *wsi, const char *allow, unsigned int flags);

/**
 * lws_http_client_http_error() - determine if the response code indicates an error
 *
 * \param code: the response code to test
 *
 * Returns nonzero if the code indicates an error, else zero if reflects a
 * non-error condition
 */
#define lws_http_client_http_resp_is_error(code) (!(code < 400))

/**
 * lws_h2_update_peer_txcredit() - manually update stream peer tx credit
 *
 * \param wsi: the h2 child stream whose peer credit to change
 * \param sid: the stream ID, or LWS_H2_STREAM_SID for the wsi stream ID
 * \param bump: signed change to confer upon peer tx credit for sid
 *
 * In conjunction with LCCSCF_H2_MANUAL_RXFLOW flag, allows the user code to
 * selectively starve the remote peer of the ability to send us data on a client
 * connection.
 *
 * Normally lws sends an initial window size for the peer to send to it of 0,
 * but during the header phase it sends a WINDOW_UPDATE to increase the amount
 * available.  LCCSCF_H2_MANUAL_RXFLOW restricts this initial increase in tx
 * credit for the stream, before it has been asked to send us anything, to the
 * amount specified in the client info .manual_initial_tx_credit member, and
 * this api can be called to send the other side permission to send us up to
 * \p bump additional bytes.
 *
 * The nwsi tx credit is updated automatically for exactly what was sent to us
 * on a stream with LCCSCF_H2_MANUAL_RXFLOW flag, but the stream's own tx credit
 * must be handled manually by user code via this api.
 *
 * Returns 0 for success or nonzero for failure.
 */
#define LWS_H2_STREAM_SID -1
LWS_VISIBLE LWS_EXTERN int
lws_h2_update_peer_txcredit(struct lws *wsi, unsigned int sid, int bump);


/**
 * lws_h2_get_peer_txcredit_estimate() - return peer tx credit estimate
 *
 * \param wsi: the h2 child stream whose peer credit estimate to return
 *
 * Returns the estimated amount of tx credit at the peer, in other words the
 * number of bytes the peer is authorized to send to us.
 *
 * It's an 'estimate' because we don't know how much is already in flight
 * towards us and actually already used.
 */
LWS_VISIBLE LWS_EXTERN int
lws_h2_get_peer_txcredit_estimate(struct lws *wsi);


/**
 * enum lws_h2_errors - HTTP/2 error code values
 *
 * These are the RST_STREAM and GOAWAY error codes defined in RFC 7540
 * section 11.4.  They are returned by lws_h2_get_peer_rst_status() and used
 * internally when emitting RST_STREAM frames.
 */
enum lws_h2_errors {
	H2_ERR_NO_ERROR,		/**< Graceful shutdown */
	H2_ERR_PROTOCOL_ERROR,		/**< Protocol error detected */
	H2_ERR_INTERNAL_ERROR,		/**< Implementation fault */
	H2_ERR_FLOW_CONTROL_ERROR,	/**< Flow-control limits exceeded */
	H2_ERR_SETTINGS_TIMEOUT,	/**< Settings not acknowledged */
	H2_ERR_STREAM_CLOSED,		/**< Frame received for closed stream */
	H2_ERR_FRAME_SIZE_ERROR,	/**< Frame size incorrect */
	H2_ERR_REFUSED_STREAM,		/**< Stream not processed */
	H2_ERR_CANCEL,			/**< Stream cancelled */
	H2_ERR_COMPRESSION_ERROR,	/**< Compression state not updated */
	H2_ERR_CONNECT_ERROR,		/**< TCP connection error for CONNECT */
	H2_ERR_ENHANCE_YOUR_CALM,	/**< Processing capacity exceeded */
	H2_ERR_INADEQUATE_SECURITY,	/**< Negotiated TLS params not acceptable */
	H2_ERR_HTTP_1_1_REQUIRED,	/**< Use HTTP/1.1 for the request */
};

/**
 * lws_h2_get_peer_rst_status() - return the peer's RST_STREAM error code
 *
 * \param wsi: the h2 stream wsi that was reset by the peer
 *
 * Returns the RFC 7540 section 11.4 error code the peer carried in the
 * RST_STREAM that closed this h2 stream, or 0 (H2_ERR_NO_ERROR) if the stream
 * was not reset by the peer.  Valid from the stream's close callbacks
 * (eg LWS_CALLBACK_CLOSED_CLIENT_HTTP, LWS_CALLBACK_CLIENT_CONNECTION_ERROR).
 *
 * This lets user code distinguish, for example, H2_ERR_REFUSED_STREAM (the
 * stream was never processed and may be retried elsewhere) from other failures.
 */
LWS_VISIBLE LWS_EXTERN uint32_t
lws_h2_get_peer_rst_status(struct lws *wsi);

///@}

