/*
 * libwebsockets - small server side websockets and web server implementation
 *
 * Copyright (C) 2010 - 2019 Andy Green <andy@warmcat.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

#if defined(LWS_WITH_OPENHITLS)
#include <crypt_eal_pkey.h>
#endif

enum enum_genec_alg {
	LEGENEC_UNKNOWN,

	LEGENEC_ECDH,
	LEGENEC_ECDSA,
	LEGENEC_EDDSA
};

/*
 * The ctx is user-allocated storage, and may be uninitialized when first
 * passed to a create() api.  create() marks the ctx once it has brought it
 * to a known state, so it can distinguish a ctx that may hold live backend
 * key handles (and must release them before re-initializing) from
 * uninitialized storage; lws_genec_destroy() clears the mark.
 */

#define LWS_GENEC_CTX_CREATED_MARK 0x4c574745u /* "LWGE" */

struct lws_genec_ctx {
#if defined(LWS_WITH_MBEDTLS)
#if !defined(LWS_HAVE_MBEDTLS_V4)
	union {
		mbedtls_ecdh_context *ctx_ecdh;
		mbedtls_ecdsa_context *ctx_ecdsa;
	} u;
#else
	psa_key_id_t key_id;
	psa_algorithm_t alg;
	uint8_t *peer_key;
	size_t peer_key_len;
#endif
#elif defined(LWS_WITH_SCHANNEL)
	struct {
		void *hAlg;
		void *hKey;
		void *hKeyPeer; /* For ECDH peer public key */
	} u;
#elif defined(LWS_WITH_GNUTLS)
	gnutls_privkey_t priv;
	gnutls_pubkey_t pub;
#elif defined(LWS_WITH_BEARSSL)
	br_ec_public_key pub;
	br_ec_private_key priv;
	void *kbuf_priv;
	void *kbuf_pub;
#elif defined(LWS_WITH_OPENHITLS)
	CRYPT_EAL_PkeyCtx *ctx[2];
#else
	EVP_PKEY_CTX *ctx[2];
#endif
	struct lws_context *context;
	const struct lws_ec_curves *curve_table;
	enum enum_genec_alg genec_alg;

	uint32_t created_mark;
	char has_private;
};

#if defined(LWS_WITH_MBEDTLS) && !defined(LWS_HAVE_MBEDTLS_V4)
enum enum_lws_dh_side {
	LDHS_OURS = MBEDTLS_ECDH_OURS,
	LDHS_THEIRS = MBEDTLS_ECDH_THEIRS
};
#else
enum enum_lws_dh_side {
	LDHS_OURS,
	LDHS_THEIRS
};
#endif

struct lws_ec_curves {
	const char *name;
	int tls_lib_nid;
	uint16_t key_bytes;
};


/* ECDH-specific apis */

/** lws_genecdh_create() - Create a genecdh
 *
 * \param ctx: your genec context
 * \param context: your lws_context (for RNG access)
 * \param curve_table: NULL, enabling P-256, P-384 and P-521, or a replacement
 *		       struct lws_ec_curves array, terminated by an entry with
 *		       .name = NULL, of curves you want to allow
 *
 * Initializes a genecdh
 *
 * \p ctx must be zeroed (eg, using memset) before it is passed to create
 * apis the first time; if the ctx is still live from an earlier create, the
 * call fails and returns nonzero.  After lws_genec_destroy() the same ctx
 * can be passed to the create apis again.
 */
LWS_VISIBLE LWS_EXTERN int
lws_genecdh_create(struct lws_genec_ctx *ctx, struct lws_context *context,
		   const struct lws_ec_curves *curve_table);

/** lws_genecdh_set_key() - Apply an EC key to our or theirs side
 *
 * \param ctx: your genecdh context
 * \param el: your key elements
 * \param side: LDHS_OURS or LDHS_THEIRS
 *
 * Applies an EC key to one side or the other of an ECDH ctx
 */
LWS_VISIBLE LWS_EXTERN int
lws_genecdh_set_key(struct lws_genec_ctx *ctx, const struct lws_gencrypto_keyelem *el,
		    enum enum_lws_dh_side side);

/** lws_genecdh_new_keypair() - Create a genec with a new public / private key
 *
 * \param ctx: your genec context
 * \param side: LDHS_OURS or LDHS_THEIRS
 * \param curve_name: an EC curve name, like "P-256"
 * \param el: array pf LWS_GENCRYPTO_EC_KEYEL_COUNT key elems to take the new key
 *
 * Creates a genecdh with a newly minted EC public / private key
 */
LWS_VISIBLE LWS_EXTERN int
lws_genecdh_new_keypair(struct lws_genec_ctx *ctx, enum enum_lws_dh_side side,
		        const char *curve_name, struct lws_gencrypto_keyelem *el);

LWS_VISIBLE LWS_EXTERN int
lws_genecdh_compute_shared_secret(struct lws_genec_ctx *ctx, uint8_t *ss,
		  int *ss_len);


/* ECDSA-specific apis */

/** lws_genecdsa_create() - Create a genecdsa and
 *
 * \param ctx: your genec context
 * \param context: your lws_context (for RNG access)
 * \param curve_table: NULL, enabling P-256, P-384 and P-521, or a replacement
 *		       struct lws_ec_curves array, terminated by an entry with
 *		       .name = NULL, of curves you want to allow
 *
 * Initializes a genecdsa.  \p ctx follows the same lifetime rules as for
 * lws_genecdh_create(): zeroed before first use, and create over a ctx that
 * is still live fails until lws_genec_destroy() is called on it.
 */
LWS_VISIBLE LWS_EXTERN int
lws_genecdsa_create(struct lws_genec_ctx *ctx, struct lws_context *context,
		    const struct lws_ec_curves *curve_table);

/** lws_genecdsa_new_keypair() - Create a genecdsa with a new public / private key
 *
 * \param ctx: your genec context
 * \param curve_name: an EC curve name, like "P-256"
 * \param el: array pf LWS_GENCRYPTO_EC_KEYEL_COUNT key elements to take the new key
 *
 * Creates a genecdsa with a newly minted EC public / private key
 */
LWS_VISIBLE LWS_EXTERN int
lws_genecdsa_new_keypair(struct lws_genec_ctx *ctx, const char *curve_name,
			 struct lws_gencrypto_keyelem *el);

/** lws_genecdsa_set_key() - Apply an EC key to an ecdsa context
 *
 * \param ctx: your genecdsa context
 * \param el: your key elements
 *
 * Applies an EC key to an ecdsa context
 */
LWS_VISIBLE LWS_EXTERN int
lws_genecdsa_set_key(struct lws_genec_ctx *ctx,
		     const struct lws_gencrypto_keyelem *el);

/** lws_genecdsa_hash_sig_verify_jws() - Verifies a JWS ECDSA signature on a given hash
 *
 * \param ctx: your struct lws_genrsa_ctx
 * \param in: unencrypted payload (usually a recomputed hash)
 * \param hash_type: one of LWS_GENHASH_TYPE_
 * \param keybits: number of bits in the crypto key
 * \param sig: pointer to the signature we received with the payload
 * \param sig_len: length of the signature we are checking in bytes
 *
 * This just looks at the signed hash... that's why there's no input length
 * parameter, it's decided by the choice of hash.  It's up to you to confirm
 * separately the actual payload matches the hash that was confirmed by this to
 * be validly signed.
 *
 * Returns <0 for error, or 0 if signature matches the hash + key..
 *
 * The JWS ECDSA signature verification algorithm differs to generic ECDSA
 * signatures and they're not interoperable.
 *
 * This and related APIs operate identically with OpenSSL or mbedTLS backends.
 */
LWS_VISIBLE LWS_EXTERN int
lws_genecdsa_hash_sig_verify_jws(struct lws_genec_ctx *ctx, const uint8_t *in,
				 enum lws_genhash_types hash_type, int keybits,
				 const uint8_t *sig, size_t sig_len);

/** lws_genecdsa_hash_sign_jws() - Creates a JWS ECDSA signature for a hash you provide
 *
 * \param ctx: your struct lws_genrsa_ctx
 * \param in: precomputed hash
 * \param hash_type: one of LWS_GENHASH_TYPE_
 * \param keybits: number of bits in the crypto key
 * \param sig: pointer to buffer to take signature
 * \param sig_len: length of the buffer (must be >= length of key N)
 *
 * Returns <0 for error, or >=0 for success.
 *
 * This creates a JWS ECDSA signature for a hash you already computed and provide.
 *
 * The JWS ECDSA signature generation algorithm differs to generic ECDSA
 * signatures and they're not interoperable.
 *
 * This and related APIs operate identically with OpenSSL or mbedTLS backends.
 */
LWS_VISIBLE LWS_EXTERN int
lws_genecdsa_hash_sign_jws(struct lws_genec_ctx *ctx, const uint8_t *in,
			   enum lws_genhash_types hash_type, int keybits,
			   uint8_t *sig, size_t sig_len);


/* EdDSA-specific apis */

/** lws_geneddsa_create() - Create a geneddsa
 *
 * \param ctx: your genec context
 * \param context: your lws_context (for RNG access)
 * \param curve_table: NULL, enabling ED25519 and ED448, or a replacement
 *		       struct lws_ec_curves array, terminated by an entry with
 *		       .name = NULL, of curves you want to allow
 *
 * Initializes a geneddsa.  \p ctx follows the same lifetime rules as for
 * lws_genecdh_create(): zeroed before first use, and create over a ctx that
 * is still live fails until lws_genec_destroy() is called on it.
 */
LWS_VISIBLE LWS_EXTERN int
lws_geneddsa_create(struct lws_genec_ctx *ctx, struct lws_context *context,
		    const struct lws_ec_curves *curve_table);

/** lws_geneddsa_new_keypair() - Create a geneddsa with a new public / private key
 *
 * \param ctx: your genec context
 * \param curve_name: an EdDSA curve name, like "ED25519"
 * \param el: array pf LWS_GENCRYPTO_OKP_KEYEL_COUNT key elements to take the new key
 *
 * Creates a geneddsa with a newly minted EdDSA public / private key
 */
LWS_VISIBLE LWS_EXTERN int
lws_geneddsa_new_keypair(struct lws_genec_ctx *ctx, const char *curve_name,
			 struct lws_gencrypto_keyelem *el);

/** lws_geneddsa_set_key() - Apply an OKP key to an eddsa context
 *
 * \param ctx: your geneddsa context
 * \param el: your key elements
 *
 * Applies an OKP key to an eddsa context
 */
LWS_VISIBLE LWS_EXTERN int
lws_geneddsa_set_key(struct lws_genec_ctx *ctx,
		     const struct lws_gencrypto_keyelem *el);

/** lws_geneddsa_hash_sig_verify_jws() - Verifies a JWS EdDSA signature on a given payload
 *
 * \param ctx: your struct lws_genrsa_ctx
 * \param in: raw payload
 * \param in_len: raw payload length
 * \param sig: pointer to the signature we received with the payload
 * \param sig_len: length of the signature we are checking in bytes
 *
 * Returns <0 for error, or 0 if signature matches the payload + key..
 */
LWS_VISIBLE LWS_EXTERN int
lws_geneddsa_hash_sig_verify_jws(struct lws_genec_ctx *ctx, const uint8_t *in,
				 size_t in_len, const uint8_t *sig, size_t sig_len);

/** lws_geneddsa_hash_sign_jws() - Creates a JWS EdDSA signature for a payload you provide
 *
 * \param ctx: your struct lws_genrsa_ctx
 * \param in: raw payload to sign
 * \param in_len: length of the payload
 * \param sig: pointer to buffer to take signature
 * \param sig_len: length of the buffer
 *
 * Returns <0 for error, or >=0 for success.
 */
LWS_VISIBLE LWS_EXTERN int
lws_geneddsa_hash_sign_jws(struct lws_genec_ctx *ctx, const uint8_t *in,
			   size_t in_len, uint8_t *sig, size_t sig_len);

/* Apis that apply to ECDH, ECDSA and EdDSA */

LWS_VISIBLE LWS_EXTERN void
lws_genec_destroy(struct lws_genec_ctx *ctx);

LWS_VISIBLE LWS_EXTERN void
lws_genec_destroy_elements(struct lws_gencrypto_keyelem *el);

LWS_VISIBLE LWS_EXTERN int
lws_genec_dump(struct lws_gencrypto_keyelem *el);
