/*
 * libwebsockets - small server side websockets and web server implementation
 *
 * Copyright (C) 2010 - 2019 Andy Green <andy@warmcat.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

/** \defgroup sock-adopt Socket adoption helpers
 * ##Socket adoption helpers
 *
 * When integrating with an external app with its own event loop, these can
 * be used to accept connections from someone else's listening socket.
 *
 * When using lws own event loop, these are not needed.
 */
///@{

/**
 * lws_adopt_socket() - adopt foreign socket as if listen socket accepted it
 * for the default vhost of context.
 *
 * \param context: lws context
 * \param accept_fd: fd of already-accepted socket to adopt
 *
 * Either returns new wsi bound to accept_fd, or closes accept_fd and
 * returns NULL, having cleaned up any new wsi pieces.
 *
 * LWS adopts the socket in http serving mode, it's ready to accept an upgrade
 * to ws or just serve http.
 */
LWS_VISIBLE LWS_EXTERN struct lws *
lws_adopt_socket(struct lws_context *context, lws_sockfd_type accept_fd);

/**
 * lws_adopt_socket_vhost() - adopt foreign socket as if listen socket accepted
 * it for vhost
 *
 * \param vh: lws vhost
 * \param accept_fd: fd of already-accepted socket to adopt
 *
 * Either returns new wsi bound to accept_fd, or closes accept_fd and
 * returns NULL, having cleaned up any new wsi pieces.
 *
 * LWS adopts the socket in http serving mode, it's ready to accept an upgrade
 * to ws or just serve http.
 */
LWS_VISIBLE LWS_EXTERN struct lws *
lws_adopt_socket_vhost(struct lws_vhost *vh, lws_sockfd_type accept_fd);

typedef enum {
	LWS_ADOPT_RAW_FILE_DESC		=  0,	/* convenience constant */
	LWS_ADOPT_HTTP			=  1,	/* flag: absent implies RAW */
	LWS_ADOPT_SOCKET		=  2,	/* flag: absent implies file */
	LWS_ADOPT_ALLOW_SSL		=  4,	/* flag: use tls */
	LWS_ADOPT_FLAG_UDP		= 16,	/* flag: socket is UDP */
	LWS_ADOPT_FLAG_RAW_PROXY	= 32,	/* flag: raw proxy */
	LWS_ADOPT_FLAG_NO_NONBLOCK	= 64,	/* flag: file fd can't be made
						 * nonblocking, and is never
						 * read in a way that can block,
						 * eg, a Darwin kqueue fd */

	LWS_ADOPT_RAW_SOCKET_UDP = LWS_ADOPT_SOCKET | LWS_ADOPT_FLAG_UDP,
} lws_adoption_type;

typedef union {
	lws_sockfd_type sockfd;
	lws_filefd_type filefd;
} lws_sock_file_fd_type;

#if defined(LWS_ESP_PLATFORM)
#include <lwip/sockets.h>
#endif

typedef union lws_sockaddr46 {
#if defined(LWS_WITH_IPV6)
	struct sockaddr_in6 sa6;
#else
#if defined(LWS_ESP_PLATFORM)
	uint8_t _pad_sa6[28];
#endif
#endif
	struct sockaddr_in sa4;
} lws_sockaddr46;

#define sa46_sockaddr(_sa46) ((struct sockaddr *)(_sa46))

#if defined(LWS_WITH_IPV6)
#define sa46_socklen(_sa46) (socklen_t)((_sa46)->sa4.sin_family == AF_INET ? \
				sizeof(struct sockaddr_in) : \
				sizeof(struct sockaddr_in6))
#define sa46_sockport(_sa46, _sp)  { if ((_sa46)->sa4.sin_family == AF_INET) \
					(_sa46)->sa4.sin_port = (_sp); else \
					(_sa46)->sa6.sin6_port = (_sp); }
#define sa46_address(_sa46) ((uint8_t *)((_sa46)->sa4.sin_family == AF_INET ? \
		     &_sa46->sa4.sin_addr : &_sa46->sa6.sin6_addr ))
#else
#define sa46_socklen(_sa46) (socklen_t)sizeof(struct sockaddr_in)
#define sa46_sockport(_sa46, _sp)  (_sa46)->sa4.sin_port = (_sp)
#define sa46_address(_sa46) (uint8_t *)&_sa46->sa4.sin_addr
#endif

#define sa46_address_len(_sa46) ((_sa46)->sa4.sin_family == AF_INET ? 4 : 16)

#if defined(LWS_WITH_UDP)
struct lws_udp {
	lws_sockaddr46		sa46;
	lws_sockaddr46		sa46_pending;
	uint8_t			connected:1;
};
#endif

/**
* lws_adopt_descriptor_vhost() - adopt foreign socket or file descriptor
* if socket descriptor, should already have been accepted from listen socket
*
* \param vh: lws vhost
* \param type: OR-ed combinations of lws_adoption_type flags
* \param fd: union with either .sockfd or .filefd set
* \param vh_prot_name: NULL or vh protocol name to bind raw connection to
* \param parent: NULL or struct lws to attach new_wsi to as a child
*
* Either returns new wsi bound to accept_fd, or closes accept_fd and
* returns NULL, having cleaned up any new wsi pieces.
*
* If LWS_ADOPT_SOCKET is set, LWS adopts the socket in http serving mode, it's
* ready to accept an upgrade to ws or just serve http.
*
* parent may be NULL, if given it should be an existing wsi that will become the
* parent of the new wsi created by this call.
*/
LWS_VISIBLE LWS_EXTERN struct lws *
lws_adopt_descriptor_vhost(struct lws_vhost *vh, lws_adoption_type type,
			   lws_sock_file_fd_type fd, const char *vh_prot_name,
			   struct lws *parent);

/**
 * lws_get_socket_fd() - returns the socket file descriptor
 *
 * This is needed to use sendto() on UDP raw sockets
 *
 * \param wsi:	Websocket connection instance
 */
LWS_VISIBLE LWS_EXTERN lws_sockfd_type
lws_get_socket_fd(struct lws *wsi);

/**
 * lws_get_udp() - get wsi's udp struct
 *
 * \param wsi: lws connection
 *
 * Returns NULL or pointer to the wsi's UDP-specific information
 */
LWS_VISIBLE LWS_EXTERN const struct lws_udp * LWS_WARN_UNUSED_RESULT
lws_get_udp(const struct lws *wsi);

#if defined(LWS_WITH_TLS) && !defined(LWS_WITH_MBEDTLS) && !defined(LWS_WITH_BEARSSL)
/**
 * lws_get_ssl() - Return wsi's SSL context structure
 * \param wsi:	websocket connection
 *
 * Returns pointer to the SSL library's context structure
 */
LWS_VISIBLE LWS_EXTERN SSL*
lws_get_ssl(struct lws *wsi);
#endif

/*
 * A transport under IO, in place of the socket.  IO still owns the wsi's
 * place in the poll set (the fd is what the loop watches), but the bytes
 * of a connection with a transport set go through these instead of recv,
 * send, recvmsg and sendto, below the tls record layer: a connection in
 * the clear exchanges its protocol bytes with the transport, one with tls
 * its ciphertext.  This is how a test drives the sansIO half with no
 * network under it (api-test-sansio), and how an embedder carries lws over
 * something that is not a socket.
 *
 * read and write follow lws_ssl_capable_read() / write(): bytes moved, or
 * LWS_SSL_CAPABLE_MORE_SERVICE_READ / _WRITE when nothing can move now, or
 * LWS_SSL_CAPABLE_ERROR; a read of 0 is the peer closing.  recv_dgram
 * returns the datagram's length with its peer and ECN bits, or 0 when
 * there is none; send_dgram as lws_io_send_dgram().  Either datagram op
 * may be NULL when the transport carries streams only.
 */
typedef struct lws_transport_ops {
	int (*read)(struct lws *wsi, void *opaque, uint8_t *buf, size_t len);
	int (*write)(struct lws *wsi, void *opaque, const uint8_t *buf,
		     size_t len);
	int (*recv_dgram)(struct lws *wsi, void *opaque, uint8_t *buf,
			  size_t len, lws_sockaddr46 *peer, uint8_t *ecn);
	int (*send_dgram)(struct lws *wsi, void *opaque, const uint8_t *buf,
			  size_t len, const lws_sockaddr46 *dest);
} lws_transport_ops_t;

/**
 * lws_set_transport() - carry a wsi's bytes over a transport, not its socket
 *
 * \param wsi: the connection (the one with the transport, not a stream)
 * \param ops: the transport, or NULL to go back to the socket
 * \param opaque: handed to every op
 */
LWS_VISIBLE LWS_EXTERN void
lws_set_transport(struct lws *wsi, const lws_transport_ops_t *ops,
		  void *opaque);

typedef struct lws_adopt_desc {
	struct lws_vhost	*vh;		/**< vhost the wsi should belong to */
	lws_adoption_type	type;		/**< OR-ed combinations of
						 * lws_adoption_type flags */
	lws_sock_file_fd_type	fd;		/**< union with either .sockfd
						 * or .filefd set */
	const char		*vh_prot_name;	/**< NULL or vh protocol name to
						 * bind raw connection to */
	struct lws		*parent; 	/**< NULL or struct lws to
						 * attach new_wsi to as a child */
	void			*opaque;	/**< opaque pointer to set on
						 *created wsi */
	const char		*fi_wsi_name;	/**< NULL, or Fault Injection
						 * inheritence filter for
						 * wsi=string/ context faults */
} lws_adopt_desc_t;

/**
* lws_adopt_descriptor_vhost_via_info() - adopt foreign socket or file descriptor
* if socket descriptor, should already have been accepted from listen socket
*
* \param info: the struct containing the parameters
*
*  - vh: lws vhost
*  - type: OR-ed combinations of lws_adoption_type flags
*  - fd: union with either .sockfd or .filefd set
*  - vh_prot_name: NULL or vh protocol name to bind raw connection to
*  - parent: NULL or struct lws to attach new_wsi to as a child
*  - opaque: opaque pointer to set on created wsi
*
* Either returns new wsi bound to accept_fd, or closes accept_fd and
* returns NULL, having cleaned up any new wsi pieces.
*
* If LWS_ADOPT_SOCKET is set, LWS adopts the socket in http serving mode, it's
* ready to accept an upgrade to ws or just serve http.
*
* parent may be NULL, if given it should be an existing wsi that will become the
* parent of the new wsi created by this call.
*/
LWS_VISIBLE LWS_EXTERN struct lws *
lws_adopt_descriptor_vhost_via_info(const lws_adopt_desc_t *info);

/**
 * lws_adopt_socket_readbuf() - adopt foreign socket and first rx as if listen socket accepted it
 * for the default vhost of context.
 * \param context:	lws context
 * \param accept_fd:	fd of already-accepted socket to adopt
 * \param readbuf:	NULL or pointer to data that must be drained before reading from
 *		accept_fd
 * \param len:	The length of the data held at \p readbuf
 *
 * Either returns new wsi bound to accept_fd, or closes accept_fd and
 * returns NULL, having cleaned up any new wsi pieces.
 *
 * LWS adopts the socket in http serving mode, it's ready to accept an upgrade
 * to ws or just serve http.
 *
 * If your external code did not already read from the socket, you can use
 * lws_adopt_socket() instead.
 *
 * This api is guaranteed to use the data at \p readbuf first, before reading from
 * the socket.
 *
 * \p readbuf is limited to the size of the ah rx buf, currently 2048 bytes.
 */
LWS_VISIBLE LWS_EXTERN struct lws *
lws_adopt_socket_readbuf(struct lws_context *context, lws_sockfd_type accept_fd,
                         const char *readbuf, size_t len);
/**
 * lws_adopt_socket_vhost_readbuf() - adopt foreign socket and first rx as if listen socket
 * accepted it for vhost.
 * \param vhost:	lws vhost
 * \param accept_fd:	fd of already-accepted socket to adopt
 * \param readbuf:	NULL or pointer to data that must be drained before reading from accept_fd
 * \param len:		The length of the data held at \p readbuf
 *
 * Either returns new wsi bound to accept_fd, or closes accept_fd and
 * returns NULL, having cleaned up any new wsi pieces.
 *
 * LWS adopts the socket in http serving mode, it's ready to accept an upgrade
 * to ws or just serve http.
 *
 * If your external code did not already read from the socket, you can use
 * lws_adopt_socket() instead.
 *
 * This api is guaranteed to use the data at \p readbuf first, before reading from
 * the socket.
 *
 * \p readbuf is limited to the size of the ah rx buf, currently 2048 bytes.
 */
LWS_VISIBLE LWS_EXTERN struct lws *
lws_adopt_socket_vhost_readbuf(struct lws_vhost *vhost,
			       lws_sockfd_type accept_fd, const char *readbuf,
			       size_t len);

#define LWS_CAUDP_BIND (1 << 0)
#define LWS_CAUDP_BROADCAST (1 << 1)
#define LWS_CAUDP_PF_PACKET (1 << 2)
/*
 * A socket connect()ed to its peer (no LWS_CAUDP_BIND) asks from a local port
 * we pick from lws_get_random() in 32768 - 65535, rather than one the OS
 * picks, which may be guessable, eg, sequential (RFC 5452, RFC 6056).  The
 * port is not shared with another socket (no SO_REUSEADDR).  If no port we
 * try can be bound, the OS picks one.
 */
#define LWS_CAUDP_RANDOM_PORT (1 << 3)

#if defined(LWS_WITH_UDP)
/**
 * lws_create_adopt_udp() - create, bind and adopt a UDP socket
 *
 * \param vhost:	 lws vhost
 * \param ads:		 NULL, an address, or a name to do dns lookup on: a
 *			 name is looked up for its A record (AAAA in a build
 *			 without ipv4), with libc or async dns alike, and the
 *			 first result is used
 * \param port:		 UDP port to bind to, -1 means unbound
 * \param flags:	 0, or LWS_CAUDP_ flags: _BIND to bind to \p ads and
 *			 \p port instead of connecting to them, _BROADCAST,
 *			 _PF_PACKET, _RANDOM_PORT
 * \param protocol_name: Name of protocol on vhost to bind wsi to
 * \param ifname:	 NULL, for network interface name to bind socket to
 * \param parent_wsi:	 NULL or parent wsi new wsi will be a child of
 * \param opaque:	 set created wsi opaque ptr to this
 * \param retry_policy:	 NULL for vhost default policy else wsi specific policy
 * \param fi_wsi_name:	 NULL, or string to inherit Fault Injection rules in
 *			 form "wsi=string/rule".  "wsi/rule" faults will be
 *			 automatically applied as well.  It's done at creation
 *			 time so the rules can, eg, inject faults related to
 *			 creation.
 *
 * Either returns new wsi bound to accept_fd, or closes accept_fd and
 * returns NULL, having cleaned up any new wsi pieces.
 * */
LWS_VISIBLE LWS_EXTERN struct lws *
lws_create_adopt_udp(struct lws_vhost *vhost, const char *ads, int port,
		     int flags, const char *protocol_name, const char *ifname,
		     struct lws *parent_wsi, void *opaque,
		     const lws_retry_bo_t *retry_policy, const char *fi_wsi_name);
#endif



///@}
