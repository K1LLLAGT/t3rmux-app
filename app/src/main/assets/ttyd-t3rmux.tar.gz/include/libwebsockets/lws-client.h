/*
 * libwebsockets - small server side websockets and web server implementation
 *
 * Copyright (C) 2010 - 2021 Andy Green <andy@warmcat.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

/*! \defgroup client Client related functions
 * ##Client releated functions
 * \ingroup lwsapi
 *
 * */
///@{

/** enum lws_client_connect_ssl_connection_flags - flags that may be used
 * with struct lws_client_connect_info ssl_connection member to control if
 * and how SSL checks apply to the client connection being created
 */

enum lws_client_connect_ssl_connection_flags {
	LCCSCF_USE_SSL 				= (1 << 0),
	LCCSCF_ALLOW_SELFSIGNED			= (1 << 1),
	LCCSCF_SKIP_SERVER_CERT_HOSTNAME_CHECK	= (1 << 2),
	LCCSCF_ALLOW_EXPIRED			= (1 << 3),
	LCCSCF_ALLOW_INSECURE			= (1 << 4),
	LCCSCF_H2_QUIRK_NGHTTP2_END_STREAM	= (1 << 5),
	LCCSCF_H2_QUIRK_OVERFLOWS_TXCR		= (1 << 6),
	LCCSCF_H2_AUTH_BEARER			= (1 << 7),
	LCCSCF_H2_HEXIFY_AUTH_TOKEN		= (1 << 8),
	LCCSCF_H2_MANUAL_RXFLOW			= (1 << 9),
	LCCSCF_HTTP_MULTIPART_MIME		= (1 << 10),
	LCCSCF_HTTP_X_WWW_FORM_URLENCODED	= (1 << 11),
	LCCSCF_HTTP_NO_FOLLOW_REDIRECT		= (1 << 12),
	LCCSCF_HTTP_NO_CACHE_CONTROL		= (1 << 13),

	LCCSCF_ALLOW_REUSE_ADDR				= (1 << 14),
	/**< allow reuse local addresses in a bind call
	 * When the listening socket is bound to INADDR_ANY with a specific port 
	 * then it is not possible to bind to this port for any local address
	 */

	LCCSCF_IPV6_PREFER_PUBLIC_ADDR				= (1 << 15),
	/**< RFC5014 - For IPv6 systems with SLAAC config, allow for preference
	 * to bind a socket to public address vs temporary private address
	 */

	LCCSCF_PIPELINE				= (1 << 16),
		/**< Serialize / pipeline multiple client connections
		 * on a single connection where possible.
		 *
		 * HTTP/1.0: possible if Keep-Alive: yes sent by server
		 * HTTP/1.1: always possible... uses pipelining
		 * HTTP/2:   always possible... uses parallel streams
		 */
	LCCSCF_MUXABLE_STREAM			= (1 << 17),
	LCCSCF_H2_PRIOR_KNOWLEDGE		= (1 << 18),
	LCCSCF_WAKE_SUSPEND__VALIDITY		= (1 << 19),
	/* our validity checks are important enough to wake from suspend */
	LCCSCF_PRIORITIZE_READS			= (1 << 20),
	/**<
	 * Normally lws balances reads and writes on all connections, so both
	 * are possible even on busy connections, and we go around the event
	 * loop more often to facilitate that, even if there is pending data.
	 *
	 * This flag indicates that you want to handle any pending reads on this
	 * connection without yielding the service loop for anything else.  This
	 * means you may block other connection processing in favour of incoming
	 * data processing on this one if it receives back to back incoming rx.
	 */
	LCCSCF_SECSTREAM_CLIENT			= (1 << 21),
	/**< used to mark client wsi as bound to secure stream */
	LCCSCF_SECSTREAM_PROXY_LINK		= (1 << 22),
	/**< client is a link between SS client and SS proxy */
	LCCSCF_SECSTREAM_PROXY_ONWARD		= (1 << 23),
	/**< client the SS proxy's onward connection */

	LCCSCF_IP_LOW_LATENCY			= (1 << 24),
	/**< set the "low delay" bit on the IP packets of this connection */
	LCCSCF_IP_HIGH_THROUGHPUT		= (1 << 25),
	/**< set the "high throughput" bit on the IP packets of this
	 *   connection */
	LCCSCF_IP_HIGH_RELIABILITY		= (1 << 26),
	/**< set the "high reliability" bit on the IP packets of this
	 *   connection */
	LCCSCF_IP_LOW_COST			= (1 << 27),
	/**< set the "minimize monetary cost" bit on the IP packets of this
	 *   connection */
	LCCSCF_CONMON				= (1 << 28),
	/**< If LWS_WITH_CONMON enabled for build, keeps a copy of the
	 * getaddrinfo results so they can be queried subsequently */
	LCCSCF_ACCEPT_TLS_DOWNGRADE_REDIRECTS	= (1 << 29),
	/**< By default lws rejects https redirecting to http.  Set this
	 * flag on the client connection to allow it. */
	LCCSCF_CACHE_COOKIES			= (1 << 30),
	/**< If built with -DLWS_WITH_CACHE_NSCOOKIEJAR, store and reapply
	 * http cookies in a Netscape Cookie Jar on this connection */
	LCCSCF_ALLOW_EARLY_DATA			= (int)(1u << 31),
	/**< Allow 0-RTT early data for QUIC/TLS 1.3 connections */
};

/*
 * All lws_tls...() functions must return this type, converting the
 * native backend result and doing the extra work to determine which one
 * as needed.
 *
 * Native TLS backend return codes are NOT ALLOWED outside the backend.
 *
 * Non-SSL mode also uses these types.
 */
enum lws_ssl_capable_status {
	LWS_SSL_CAPABLE_ERROR			= -1, /* it failed */
	LWS_SSL_CAPABLE_DONE			= 0,  /* it succeeded */
	LWS_SSL_CAPABLE_MORE_SERVICE_READ	= -2, /* retry WANT_READ */
	LWS_SSL_CAPABLE_MORE_SERVICE_WRITE	= -3, /* retry WANT_WRITE */
};

/** struct lws_client_connect_info - parameters to connect with when using
 *				    lws_client_connect_via_info() */

struct lws_client_connect_info {
	struct lws_context *context;
	/**< lws context to create connection in */
	const char *address;
	/**< remote address to connect to */
	int port;
	/**< remote port to connect to */
	int ssl_connection;
	/**< 0, or a combination of LCCSCF_ flags */
	const char *path;
	/**< URI path. Prefix with + for a UNIX socket. (+@ for
     * a Linux abstract-namespace socket) */
	const char *host;
	/**< content of host header */
	const char *origin;
	/**< content of origin header */
	const char *protocol;
	/**< list of ws protocols we could accept */
	int ietf_version_or_minus_one;
	/**< deprecated: currently leave at 0 or -1 */
	void *userdata;
	/**< if non-NULL, use this as wsi user_data instead of malloc it */
	const void *client_exts;
	/**< UNUSED... provide in info.extensions at context creation time */
	const char *method;
	/**< if non-NULL, do this http method instead of ws[s] upgrade.
	 * use "GET" to be a simple http client connection.  "RAW" gets
	 * you a connected socket that lws itself will leave alone once
	 * connected. */
	struct lws *parent_wsi;
	/**< if another wsi is responsible for this connection, give it here.
	 * this is used to make sure if the parent closes so do any
	 * child connections first. */
	const char *uri_replace_from;
	/**< if non-NULL, when this string is found in URIs in
	 * text/html content-encoding, it's replaced with uri_replace_to */
	const char *uri_replace_to;
	/**< see uri_replace_from */
	struct lws_vhost *vhost;
	/**< vhost to bind to (used to determine related SSL_CTX) */
	struct lws **pwsi;
	/**< if not NULL, store the new wsi here early in the connection
	 * process.  Although we return the new wsi, the call to create the
	 * client connection does progress the connection somewhat and may
	 * meet an error that will result in the connection being scrubbed and
	 * NULL returned.  While the wsi exists though, he may process a
	 * callback like CLIENT_CONNECTION_ERROR with his wsi: this gives the
	 * user callback a way to identify which wsi it is that faced the error
	 * even before the new wsi is returned and even if ultimately no wsi
	 * is returned.
	 */
	const char *iface;
	/**< NULL to allow routing on any interface, or interface name or IP
	 * to bind the socket to */
	int local_port;
	/**< 0 to pick an ephemeral port, or a specific local port
	 * to bind the socket to */
	const char *local_protocol_name;
	/**< NULL: .protocol is used both to select the local protocol handler
	 *         to bind to and as the list of remote ws protocols we could
	 *         accept.
	 *   non-NULL: this protocol name is used to bind the connection to
	 *             the local protocol handler.  .protocol is used for the
	 *             list of remote ws protocols we could accept */
	const char *alpn;
	/**< NULL: allow lws default ALPN list, from vhost if present or from
	 *       list of roles built into lws
	 * non-NULL: require one from provided comma-separated list of alpn
	 *           tokens
	 */

	void *opaque_user_data;
	/**< This data has no meaning to lws but is applied to the client wsi
	 *   and can be retrieved by user code with lws_get_opaque_user_data().
	 *   It's also provided with sequencer messages if the wsi is bound to
	 *   an lws_seq_t.
	 */

	const lws_retry_bo_t *retry_and_idle_policy;
	/**< optional retry and idle policy to apply to this connection.
	 *   Currently only the idle parts are applied to the connection.
	 */

	int		manual_initial_tx_credit;
	/**< if LCCSCF_H2_MANUAL_REFLOW is set, this becomes the initial tx
	 * credit for the stream.
	 */

	uint8_t		sys_tls_client_cert;
	/**< 0 means no client cert.  1+ means apply lws_system client cert 0+
	 * to the client connection.
	 */

	uint8_t		priority;
	/**< 0 means normal priority... otherwise sets the IP priority on
	 * packets coming from this connection, from 1 - 7.  Setting 7
	 * (network management priority) requires CAP_NET_ADMIN capability but
	 * the others can be set by anyone.
	 */

#if defined(LWS_ROLE_MQTT)
	const lws_mqtt_client_connect_param_t *mqtt_cp;
#else
	void		*mqtt_cp;
#endif

#if defined(LWS_WITH_SYS_FAULT_INJECTION)
	lws_fi_ctx_t				fic;
	/**< Attach external Fault Injection context to the client wsi,
	 * hierarchy is wsi -> vhost -> context */
#endif
	/* for convenience, available when FI disabled in build */
	const char				*fi_wsi_name;
	/**< specific Fault Injection namespace name for wsi created for this
	 * connection, allows targeting by "wsi=XXX/..." if you give XXX here.
	 */

	uint16_t				keep_warm_secs;
	/**< 0 means 5s.  If the client connection to the endpoint becomes idle,
	 * defer closing it for this many seconds in case another outgoing
	 * connection to the same endpoint turns up.  For h1 that is the
	 * connection after its transaction completed; for h2 and h3 it is the
	 * shared connection after its last stream closed.  A connection that
	 * serves several requests in turn keeps warm for the time asked by the
	 * request that last used it.
	 */

	lws_log_cx_t				*log_cx;
	/**< NULL to use lws_context log context, else a pointer to a log
	 * context template to take a copy of for this wsi.  Used to isolate
	 * wsi-specific logs into their own stream or file.
	 */
	const char *auth_username;
	const char *auth_password;

#if defined(LWS_ROLE_WS)
	uint8_t		allow_reserved_bits;
	/**< non-zero to allow reserved bits. You can get it by lws_get_reserved_bits().
	 * Note: default zero means close the websocket connection for non-zero rsv.
	 */

	uint8_t		allow_unknown_opcode;
	/**< non-zero to allow unknown opcode. You can get it by `lws_get_opcode`.
	 * None: default zero means close the websocket connection for unknown opcode.
	 */
#endif

	uint8_t         disable_h3_fallback;
	/**< non-zero to disable the Happy Eyeballs QUIC fallback timer.
	 * When set, QUIC connections will wait for the full connect timeout
	 * instead of falling back to TCP after the H3 grace period.
	 */

	const struct lws_transport_ops *transport;
	/**< NULL, or a transport under IO in place of a socket
	 * (lws_set_transport()): no dns lookup or connect is made, the
	 * connection starts on the transport as if connected, and
	 * transport_fd is its place in the poll set.  The fd is the
	 * connection's from this call on, and is closed with it.  Such a
	 * connection can't use LCCSCF_USE_SSL (the tls backends would read
	 * and write the fd directly), and can't be restarted by a redirect
	 * or a digest auth retry. */
	void		*transport_opaque;
	/**< handed to every op of transport */
	lws_sockfd_type	transport_fd;
	/**< with transport: the fd the event loop watches for the connection */

	/* Add new things just above here ---^
	 * This is part of the ABI, don't needlessly break compatibility
	 *
	 * The below is to ensure later library versions with new
	 * members added above will see 0 (default) even if the app
	 * was not built against the newer headers.
	 */

	void *_unused[3]; /**< dummy */
};

/**
 * lws_client_connect_via_info() - Connect to another websocket server
 * \param ccinfo: pointer to lws_client_connect_info struct
 *
 *	This function creates a connection to a remote server using the
 *	information provided in ccinfo.
 */
LWS_VISIBLE LWS_EXTERN struct lws *
lws_client_connect_via_info(const struct lws_client_connect_info *ccinfo);

/**
 * lws_init_vhost_client_ssl() - also enable client SSL on an existing vhost
 *
 * \param info: client ssl related info
 * \param vhost: which vhost to initialize client ssl operations on
 *
 * You only need to call this if you plan on using SSL client connections on
 * the vhost.  For non-SSL client connections, it's not necessary to call this.
 *
 * The following members of info are used during the call
 *
 *	 - options must have LWS_SERVER_OPTION_DO_SSL_GLOBAL_INIT set,
 *	     otherwise the call does nothing
 *	 - provided_client_ssl_ctx must be NULL to get a generated client
 *	     ssl context, otherwise you can pass a prepared one in by setting it
 *	 - ssl_cipher_list may be NULL or set to the client valid cipher list
 *	 - ssl_ca_filepath may be NULL or client cert filepath
 *	 - ssl_cert_filepath may be NULL or client cert filepath
 *	 - ssl_private_key_filepath may be NULL or client cert private key
 *
 * You must create your vhost explicitly if you want to use this, so you have
 * a pointer to the vhost.  Create the context first with the option flag
 * LWS_SERVER_OPTION_EXPLICIT_VHOSTS and then call lws_create_vhost() with
 * the same info struct.
 */
LWS_VISIBLE LWS_EXTERN int
lws_init_vhost_client_ssl(const struct lws_context_creation_info *info,
			  struct lws_vhost *vhost);
/**
 * lws_http_client_read() - consume waiting received http client data
 *
 * \param wsi: client connection
 * \param buf: pointer to buffer pointer - fill with pointer to your buffer
 * \param len: pointer to chunk length - fill with max length of buffer
 *
 * This is called when the user code is notified client http data has arrived.
 * The user code may choose to delay calling it to consume the data, for example
 * waiting until an onward connection is writeable.
 *
 * For non-chunked connections, up to len bytes of buf are filled with the
 * received content.  len is set to the actual amount filled before return.
 *
 * For chunked connections, the linear buffer content contains the chunking
 * headers and it cannot be passed in one lump.  Instead, this function will
 * call back LWS_CALLBACK_RECEIVE_CLIENT_HTTP_READ with in pointing to the
 * chunk start and len set to the chunk length.  There will be as many calls
 * as there are chunks or partial chunks in the buffer.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_client_read(struct lws *wsi, char **buf, int *len);

/**
 * lws_http_client_http_response() - get last HTTP response code
 *
 * \param wsi: client connection
 *
 * Returns the last server response code, eg, 200 for client http connections.
 * If there is no valid response, it will return 0.
 *
 * You should capture this during the LWS_CALLBACK_ESTABLISHED_CLIENT_HTTP
 * callback, because after that the memory reserved for storing the related
 * headers is freed and this value is lost.
 */
LWS_VISIBLE LWS_EXTERN unsigned int
lws_http_client_http_response(struct lws *wsi);

/**
 * lws_client_redirect_info_t - where a redirected client request goes
 */
typedef struct lws_client_redirect_info {
	const char	*address;	/**< what it connects to */
	const char	*host;		/**< its Host: header, the authority */
	const char	*path;		/**< from the '/', with any query */
	int		port;		/**< the port it connects to */
	uint8_t		tls;		/**< 1: over tls, ie, https */
	uint8_t		credentials_ok;
	/**< 1: credentials set for the request before it was redirected may
	 * go there too: it is https with strict tls verification (none of
	 * LCCSCF_ALLOW_SELFSIGNED, LCCSCF_SKIP_SERVER_CERT_HOSTNAME_CHECK,
	 * LCCSCF_ALLOW_EXPIRED or LCCSCF_ALLOW_INSECURE), to the host the
	 * request started with or a subdomain of it (Go net/http's rule).
	 * 0: they must not go there */
} lws_client_redirect_info_t;

/**
 * lws_client_redirect_info() - where a client request is being redirected
 *
 * \param wsi: client connection
 * \param info: filled with where the request goes, if it is redirected
 *
 * Headers added in LWS_CALLBACK_CLIENT_APPEND_HANDSHAKE_HEADER are added
 * again to the request a redirect makes, to wherever the server's Location
 * takes it.  So user code adding credentials there (an Authorization, an api
 * key...) must judge where they would go.
 *
 * In LWS_CALLBACK_CLIENT_HTTP_REDIRECT, this tells where the redirect would
 * take the request, as lws resolved the Location; returning nonzero from the
 * callback refuses the redirect, and the connection fails.  In
 * LWS_CALLBACK_CLIENT_APPEND_HANDSHAKE_HEADER, it tells where a request that
 * was redirected is going now.  In either, \p info->credentials_ok says
 * whether credentials set for the request before its first redirect may go
 * there; refuse the redirect rather than strip them and follow it, so the
 * failure is visible.
 *
 * Cookies from the lws cookie jar (LCCSCF_CACHE_COOKIES) and digest auth
 * credentials are sent by lws for the user code: lws itself refuses a
 * redirect that would take them where \p info->credentials_ok is 0.
 *
 * The strings in \p info are valid only during the callback.
 *
 * Returns 0 with \p info filled, or nonzero if the request is not being, or
 * was not, redirected.
 */
LWS_VISIBLE LWS_EXTERN int
lws_client_redirect_info(struct lws *wsi, lws_client_redirect_info_t *info);

/**
 * lws_tls_client_vhost_extra_cert_mem() - add more certs to vh client tls ctx
 *
 * \param vh: the vhost to give more client certs to
 * \param der: pointer to der format additional cert
 * \param der_len: size in bytes of der
 *
 * After the vhost is created with one cert for client verification, you
 * can add additional, eg, intermediate, certs to the client tls context
 * of the vhost, for use with validating the incoming server cert(s).
 *
 * The cert is trusted by this vhost only.  Some tls backends (OpenSSL,
 * OpenHiTLS) share one client tls ctx between vhosts created with identical
 * client tls configuration; adding trust to a ctx that another vhost shares
 * would make that vhost trust the cert too, so this fails instead.  Create
 * vhosts you will add trust to with \p info.client_ssl_ctx_unshared set.
 * Once trust was added, no vhost created later shares the vhost's ctx.
 *
 * Returns 0 if the cert was added, else nonzero.
 */
LWS_VISIBLE LWS_EXTERN int
lws_tls_client_vhost_extra_cert_mem(struct lws_vhost *vh,
		const uint8_t *der, size_t der_len);

/**
 * lws_client_http_body_pending() - control if client connection needs to send body
 *
 * \param wsi: client connection
 * \param something_left_to_send: nonzero if need to send more body, 0 (default)
 * 				if nothing more to send
 *
 * If you will send payload data with your HTTP client connection, eg, for POST,
 * when you set the related http headers in
 * LWS_CALLBACK_CLIENT_APPEND_HANDSHAKE_HEADER callback you should also call
 * this API with something_left_to_send nonzero, and call
 * lws_callback_on_writable(wsi);
 *
 * After sending the headers, lws will call your callback with
 * LWS_CALLBACK_CLIENT_HTTP_WRITEABLE reason when writable.  You can send the
 * next part of the http body payload, calling lws_callback_on_writable(wsi);
 * if there is more to come, or lws_client_http_body_pending(wsi, 0); to
 * let lws know the last part is sent and the connection can move on.
 *
 * The body must be framed for the server to know where it ends.  If you
 * know its length, add a Content-Length header in the
 * LWS_CALLBACK_CLIENT_APPEND_HANDSHAKE_HEADER callback and lws sends what
 * you write as it is.  If you add neither that nor a Transfer-Encoding, lws
 * adds "Transfer-Encoding: chunked" to the head (with a NOTICE saying so)
 * and frames each lws_write() as one chunk, the one written with
 * LWS_WRITE_HTTP_FINAL followed by the last-chunk; a write of length zero
 * that is not final sends nothing.  Over h2 the stream frames the body and
 * neither header is needed.
 */
LWS_VISIBLE LWS_EXTERN void
lws_client_http_body_pending(struct lws *wsi, int something_left_to_send);

/**
 * lws_client_http_multipart() - issue appropriate multipart header or trailer
 *
 * \param wsi: client connection
 * \param name: multipart header name field, or NULL if end of multipart
 * \param filename: multipart header filename field, or NULL if none
 * \param content_type: multipart header content-type part, or NULL if none
 * \param p: pointer to position in buffer
 * \param end: end of buffer
 *
 * This issues a multipart mime boundary, or terminator if name = NULL.
 *
 * \p name and \p filename go in quoted-strings in the part's
 * Content-Disposition, so they must not contain '"', '\\' or control
 * characters, and \p content_type must not contain control characters other
 * than tab: such a part is refused rather than escaped.  \p filename should
 * be only the name of the file, without any local path.
 *
 * Returns 0 if OK or nonzero if couldn't fit in buffer, or the name,
 * filename or content type can't be used.  When they can't be used, nothing
 * is written at \p p.
 *
 * This is deprecated in favour of the below lws_http_mp apis
 */
LWS_VISIBLE LWS_EXTERN int
lws_client_http_multipart(struct lws *wsi, const char *name,
			  const char *filename, const char *content_type,
			  char **p, char *end);

struct lws_http_mp_sm;
/**
 * lws_http_mp_sm_cb_t() - gets the next form element for lws_http_mp_sm
 *
 * \p cx: the lws_context
 * \p ft: buffer to copy the next form element into, as a NUL-terminated string
 * \p ft_len: size of \p ft
 * \p last: the app's iterator: NULL when the form starts from its first
 *	     element, and otherwise whatever the cb set it to last time
 *
 * The element is "name=value" for a form field, or "name=@path" to send the
 * contents of the file at path.  The file part's filename is only the last
 * component of path.  Neither the name nor that filename may contain '"',
 * '\\' or control characters, since they go in quoted-strings in the part
 * headers: a form with such an element is refused.
 *
 * The callback returns 0 with the element in \p ft, 1 when there are no more
 * elements, or -1 on error.
 *
 * It's called to go through the whole form twice: first at
 * lws_http_mp_sm_init() to compute the Content-Length, and then again from
 * the start to send it from lws_http_mp_sm_fill().  It must give the same
 * elements both times.  An element must be shorter than \p ft_len - 1: the
 * callback should return -1 for one that does not fit rather than truncate
 * it, and one that fills \p ft completely is refused as possibly truncated.
 */
typedef int (*lws_http_mp_sm_cb_t)(struct lws_context *cx, char *ft, size_t ft_len, const char **last);

/**
 * lws_http_mp_sm_init() - allocate and init an http post multipart state machine
 *
 * \p wsi: the wsi this will be used on
 * \p cb: the http_mp callback for getting next form item
 * \p p: pointer to pointer to next header byte
 * \p end: pointer to last possible header byte
 *
 * Goes through the form with \p cb, adding the Content-Type and the exact
 * Content-Length of the multipart body to the request headers.
 *
 * Returns a new and initialized multipart post state machine object,
 * or NULL if OOM, a form element is unusable (too long, no '=', a file that
 * can't be stat()ed) or other problems.
 */
LWS_VISIBLE LWS_EXTERN struct lws_http_mp_sm *
lws_http_mp_sm_init(struct lws *wsi, lws_http_mp_sm_cb_t cb, uint8_t **p, uint8_t *end);

/**
 * lws_http_mp_sm_destroy() - deallocates an http post multipart state machine
 *
 * \p pphms: pointer to http_mp_sm pointer
 *
 * Frees and sets the pointed-to pointer to NULL.
 */
LWS_VISIBLE LWS_EXTERN void
lws_http_mp_sm_destroy(struct lws_http_mp_sm **pphms);

/**
 * lws_http_mp_sm_fill() - fills a buffer with the next fragment of form data
 *
 * \p phms: pointer to http_mp_sm
 * \p p: cursor into buffer - moved on by call
 * \p end: one past the last byte that may be written
 *
 * Fills \p *p potentially to \p end with form data, and moves
 * *p on by the amount used.
 *
 * The body never exceeds the Content-Length lws_http_mp_sm_init() declared.
 * If the form no longer matches it, eg, a cb element changed or a file was
 * truncated or grew since, the fill fails rather than send a body of a
 * different length.
 *
 * Returns 1 if there is more to send (call again on the next WRITEABLE),
 * 0 if this was the end of the body, or -1 for failure, in which case
 * nothing from this call should be sent and the connection should be
 * closed, since the body can't be completed.  *p has been moved on to show
 * the extent of the written amount for 0 and 1.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_mp_sm_fill(struct lws_http_mp_sm *phms, uint8_t **p, uint8_t *end);


/**
 * lws_http_basic_auth_gen() - helper to encode client basic auth string
 *
 * \param user: user name
 * \param pw: password
 * \param buf: where to store base64 result
 * \param len: max usable size of buf
 *
 * Encodes a username and password in Basic Auth format for use with the
 * Authorization header.  On return, buf is filled with something like
 * "Basic QWxhZGRpbjpPcGVuU2VzYW1l".
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_basic_auth_gen(const char *user, const char *pw, char *buf, size_t len);

/**
 * lws_http_basic_auth_gen2() - helper to encode client basic auth string
 *
 * \param user: user name
 * \param pw: password
 * \param pwd_len: count of bytes in password
 * \param buf: where to store base64 result
 * \param len: max usable size of buf
 *
 * Encodes a username and password in Basic Auth format for use with the
 * Authorization header.  On return, buf is filled with something like
 * "Basic QWxhZGRpbjpPcGVuU2VzYW1l".
 *
 * This differs from lws_http_baic_auth_gen() in that NUL bytes can
 * appear in the password due to an explicit password length argument.
 */
LWS_VISIBLE LWS_EXTERN int
lws_http_basic_auth_gen2(const char *user, const void *pw, size_t pwd_len,
                         char *buf, size_t len);

/**
 * lws_tls_session_is_reused() - returns nonzero if tls session was cached
 *
 * \param wsi: the wsi
 *
 * Returns zero if the tls session is fresh, else nonzero if the tls session was
 * taken from the cache.  If lws is built with LWS_WITH_TLS_SESSIONS and the vhost
 * was created with the option LWS_SERVER_OPTION_ENABLE_TLS_SESSION_CACHE, then
 * on full tls session establishment of a client connection, the session is added
 * to the tls cache.
 *
 * This lets you find out if your session was new (0) or from the cache (nonzero),
 * it'a mainly useful for stats and testing.
 */
LWS_VISIBLE LWS_EXTERN int
lws_tls_session_is_reused(struct lws *wsi);

/**
 * lws_tls_client_connect() - perform/progress TLS handshake on client connection
 *
 * \param wsi: client connection
 * \param errbuf: buffer for error string
 * \param len: length of errbuf
 *
 * This is usually handled automatically by lws if LCCSCF_USE_SSL was set on
 * the connection. However for STARTTLS type protocols, the connection
 * starts in cleartext and this can be called manually later to perform the
 * TLS handshake.
 */
LWS_VISIBLE LWS_EXTERN enum lws_ssl_capable_status
lws_tls_client_connect(struct lws *wsi, char *errbuf, size_t len);

/**
 * lws_tls_client_upgrade() - upgrade a non-TLS client connection to TLS
 *
 * \param wsi: established raw client connection with no tls yet
 * \param ssl_flags: LCCSCF_ flags to apply, including LCCSCF_USE_SSL
 *
 * For STARTTLS type protocols, this can be called to transition a RAW
 * connection to TLS, eg, from LWS_CALLBACK_RAW_RX once the peer has agreed
 * to it.  The peer certificate is checked against the connection's vhost
 * client tls context and the host the connection was made to, according to
 * \p ssl_flags, as for a connection that used tls from the start.
 *
 * The first step of the handshake is taken inside this call, and lws carries
 * on with the rest.  When it has completed, the connection's protocol
 * receives LWS_CALLBACK_RAW_CONNECTED again, and from then on its rx and tx
 * are over the tls.  A handshake that fails or times out closes the
 * connection with LWS_CALLBACK_RAW_CLOSE, since it was already connected.
 *
 * Any plaintext the peer sent after agreeing to start tls must be discarded,
 * not acted on: it was not protected by the tls.  What the caller was given
 * in the same RAW_RX, after the peer's agreement, is the caller's to refuse;
 * lws refuses the connection if any more of it is buffered, rather than
 * deliver it after the tls is up.
 *
 * Returns 0 if the handshake is under way, 1 if it completed already inside
 * this call (no LWS_CALLBACK_RAW_CONNECTED will follow), or -1 if tls could
 * not be started, in which case the caller should close the connection.
 */
LWS_VISIBLE LWS_EXTERN int
lws_tls_client_upgrade(struct lws *wsi, int ssl_flags);

/**
 * struct lws_alt_svc - result of parsing an Alt-Svc alternative (RFC 7838)
 *
 * \warning this is a fixed-size struct matched against sizeof in the api test,
 * changing it is an ABI change
 */
struct lws_alt_svc {
	char		host[64];
	/**< alternative authority host, empty string means "same host as the
	 * origin" */
	uint32_t	ma_secs;
	/**< max-age for the alternative in seconds, already capped at
	 * 24h; 0 means "delete any existing alternative" */
	uint16_t	port;
	/**< the port the alternative is available on */
};

/**
 * lws_client_alt_svc_parse() - parse an Alt-Svc header value for an h3
 *				alternative
 *
 * \param val: the Alt-Svc header value
 * \param len: length of \p val
 * \param alt: lws_alt_svc struct to receive the result
 *
 * Parses header values like `h3=":443"; ma=86400`, looking for the first
 * well-formed `h3` alternative.  This is a pure function of its inputs,
 * suitable for unit testing.  The header value is untrusted input and
 * anything malformed is ignored rather than partially trusted.
 *
 * Returns 1 if a well-formed h3 alternative was found and \p alt filled in
 * (with \p host left empty for the same-host `":port"` form), or 0 if there
 * is nothing usable for h3 in \p val.  The \p ma_secs field defaults to 24h
 * capped when no explicit max-age was given.
 */
LWS_VISIBLE LWS_EXTERN int
lws_client_alt_svc_parse(const char *val, size_t len,
			 struct lws_alt_svc *alt);

///@}
